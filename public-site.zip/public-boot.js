(()=>{
 const VERSION="public-a34542ad1d11",script=document.currentScript,base=new URL('./',script.src),prefix='school-unlocked-'+base.pathname;
 const ownWorker=worker=>worker&&new URL(worker.scriptURL).href===new URL('sw.js',base).href;
 const deleteOldCaches=async()=>{if(!('caches'in window))return;for(const key of await caches.keys())if(key===prefix||key.startsWith(prefix))await caches.delete(key)};
 window.schoolPublicReady=(async()=>{
  if(!('serviceWorker'in navigator)||!window.isSecureContext)return;
  const registrations=await navigator.serviceWorker.getRegistrations();
  const old=registrations.find(reg=>reg.scope===base.href),oldController=navigator.serviceWorker.controller;
  if(!old&&!ownWorker(oldController))return;
  let removeListener=()=>{};
  const ready=new Promise(resolve=>{
   const finish=()=>{removeListener();resolve(true)};
   const receive=event=>{if(event.data?.type==='school-public-ready'&&event.data.version===VERSION)finish()};
   navigator.serviceWorker.addEventListener('message',receive);
   removeListener=()=>navigator.serviceWorker.removeEventListener('message',receive);
  });
  let reg;
  try{
   reg=await navigator.serviceWorker.register(new URL('sw.js',base),{scope:base.pathname,updateViaCache:'none'});
   await reg.update();
   const worker=reg.active;
   if(worker){const channel=new MessageChannel();channel.port1.onmessage=event=>{if(event.data?.version===VERSION&&event.data.ready)navigator.serviceWorker.dispatchEvent(new MessageEvent('message',{data:{type:'school-public-ready',version:VERSION}}));channel.port1.close()};worker.postMessage({type:'school-public-status'},[channel.port2]);}
   const complete=await Promise.race([ready,new Promise(resolve=>setTimeout(()=>resolve(false),7000))]);
   removeListener();
   if(complete)return;
  }catch{removeListener();}
  // Network/update failure fallback: unregister this exact scope, remove only
  // its old caches, and make one fresh navigation before loading app modules.
  await deleteOldCaches();
  for(const registration of await navigator.serviceWorker.getRegistrations())if(registration.scope===base.href)await registration.unregister();
  if(ownWorker(navigator.serviceWorker.controller)){
   const url=new URL(location.href);
   if(url.searchParams.get('public-reload')!==VERSION){url.searchParams.set('public-reload',VERSION);location.replace(url);await new Promise(()=>{});}
  }
 })().catch(()=>{});
 document.addEventListener('click',event=>{const link=event.target.closest?.('a[data-school-model]');if(!link||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;event.preventDefault();window.schoolPublicReady.then(()=>location.assign(link.href))});
})();
