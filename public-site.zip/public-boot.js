(()=>{
 const VERSION="public-31002ebb7814",script=document.currentScript,base=new URL('./',script.src),prefix='school-unlocked-'+base.pathname;
 const ownWorker=worker=>worker&&new URL(worker.scriptURL).href===new URL('sw.js',base).href;
 let expired=false,timer,removeListener=()=>{},channel;
 const deadline=new Promise(resolve=>{timer=setTimeout(()=>{expired=true;resolve(false)},2500)});
 const bounded=async operation=>{
  if(expired)throw Error('Migration deadline');
  const result=await Promise.race([Promise.resolve().then(operation).then(value=>({value}),error=>({error})),deadline.then(()=>({timeout:true}))]);
  if(result.timeout||expired)throw Error('Migration deadline');
  if(result.error)throw result.error;
  return result.value;
 };
 const deleteOldCaches=async()=>{if(!('caches'in window))return;for(const key of await bounded(()=>caches.keys()))if(key===prefix||key.startsWith(prefix))await bounded(()=>caches.delete(key))};
 const migrate=async()=>{
  if(!('serviceWorker'in navigator)||!window.isSecureContext)return;
  const registrations=await bounded(()=>navigator.serviceWorker.getRegistrations());
  const old=registrations.find(reg=>reg.scope===base.href),oldController=navigator.serviceWorker.controller;
  if(!old&&!ownWorker(oldController))return;
  const ready=new Promise(resolve=>{
   const finish=()=>{removeListener();resolve(true)};
   const receive=event=>{if(event.data?.type==='school-public-ready'&&event.data.version===VERSION)finish()};
   navigator.serviceWorker.addEventListener('message',receive);
   removeListener=()=>navigator.serviceWorker.removeEventListener('message',receive);
  });
  let reg;
  try{
   reg=await bounded(()=>navigator.serviceWorker.register(new URL('sw.js',base),{scope:base.pathname,updateViaCache:'none'}));
   await bounded(()=>reg.update());
   const worker=reg.active;
   if(worker){channel=new MessageChannel();channel.port1.onmessage=event=>{if(!expired&&event.data?.version===VERSION&&event.data.ready)navigator.serviceWorker.dispatchEvent(new MessageEvent('message',{data:{type:'school-public-ready',version:VERSION}}));channel.port1.close()};worker.postMessage({type:'school-public-status'},[channel.port2]);}
   const complete=await bounded(()=>Promise.race([ready,new Promise(resolve=>setTimeout(()=>resolve(false),750))]));
   removeListener();
   if(complete)return;
  }catch{removeListener();}
  // Network/update failure fallback: unregister this exact scope, remove only
  // its old caches, and make one fresh navigation before loading app modules.
  if(expired)return;
  await deleteOldCaches();
  for(const registration of await bounded(()=>navigator.serviceWorker.getRegistrations()))if(registration.scope===base.href)await bounded(()=>registration.unregister());
  if(ownWorker(navigator.serviceWorker.controller)){
   const url=new URL(location.href);
   if(url.searchParams.get('public-reload')!==VERSION){url.searchParams.set('public-reload',VERSION);location.replace(url);}
  }
 };
 window.schoolPublicReady=Promise.race([migrate().catch(()=>{}),deadline]).finally(()=>{expired=true;clearTimeout(timer);removeListener();channel?.port1.close()});
})();
