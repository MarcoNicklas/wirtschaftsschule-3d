import * as THREE from 'three';
import {GLTFLoader} from './vendor/loaders/GLTFLoader.js';
import {OrbitControls} from './vendor/controls/OrbitControls.js';
import {probeVR,requestVR,getRoomSpawn,pickRoomAt,isGroupVisible} from './vr-core.js?v=8b765c86b9dd';

const $=id=>document.getElementById(id);
const dom={stage:$('stage'),status:$('status'),enter:$('enter-vr'),model:$('mode-model'),room:$('mode-room'),
 floor:$('floor-choice'),rooms:$('room-choice'),reset:$('reset-view'),retry:$('retry'),title:$('scene-title'),
 support:$('vr-support'),progress:$('load-progress')};
const floorNames={EG:'Erdgeschoss','1OG':'1. Obergeschoss','2OG':'2. Obergeschoss'};
const state={ready:false,mode:'model',floor:'EG',roomId:'Pausenhalle_E_50',xr:false,starting:false,
 supported:false,referenceSpaceType:'local-floor',desktop:null,menuOpen:true};
let renderer,camera,scene,rig,controls,world,model,table,environment,menu,menuTitle;
let metadata={},rooms=[],available=[],routes={},meshes=[],floorMeshes=[],labels=[],menuButtons=[];
let marker,tableScale=1,sourceBounds,session=null,contextLost=false,recenterPending=false;
const controllers=[],raycaster=new THREE.Raycaster(),rotation=new THREE.Matrix4();
const point=new THREE.Vector3(),headPosition=new THREE.Vector3(),headForward=new THREE.Vector3();
const roomLabel=room=>room?.display_name||room?.source_name||room?.name||room?.id||'Raum';
const selectedRoom=()=>rooms.find(room=>room.id===state.roomId);
const announce=message=>{dom.status.textContent=message;};
// Bind recovery before creating WebGL: a constructor failure still needs a
// working way to retry after the browser or graphics context recovers.
dom.retry.addEventListener('click',()=>location.reload());

function fail(message,error){
 announce(message);dom.retry.hidden=false;dom.progress.hidden=true;
 if(error)console.error('VR viewer:',error);
}

function roomChoices(){return available.filter(room=>state.floor==='all'||room.storey===state.floor);}

function syncChoices(){
 const choices=roomChoices();
 if(!choices.some(room=>room.id===state.roomId))state.roomId=choices[0]?.id||available[0]?.id||'';
 dom.rooms.replaceChildren();
 for(const storey of ['EG','1OG','2OG']){
  const list=choices.filter(room=>room.storey===storey);if(!list.length)continue;
  const group=document.createElement('optgroup');group.label=floorNames[storey];
  for(const room of list)group.append(new Option(roomLabel(room),room.id));
  dom.rooms.append(group);
 }
 dom.rooms.value=state.roomId;dom.floor.value=state.floor;
}

function syncUI(){
 dom.enter.disabled=!state.ready||!state.supported||state.starting||contextLost;
 dom.enter.textContent=state.xr?'VR beenden':state.starting?'VR wird geöffnet …':'VR starten';
 dom.model.disabled=dom.room.disabled=dom.floor.disabled=dom.rooms.disabled=dom.reset.disabled=!state.ready;
 dom.model.setAttribute('aria-pressed',String(state.mode==='model'));
 dom.room.setAttribute('aria-pressed',String(state.mode==='room'));
 dom.floor.value=state.floor;dom.rooms.value=state.roomId;
 const name=roomLabel(selectedRoom());
 dom.title.textContent=(state.mode==='model'?'Schule als Modell':'Im Schulhaus')+' · '+name;
 if(menuTitle)paintText(menuTitle,name+'\n'+(state.mode==='model'?'Tischmodell':'Im Schulhaus')+' · '+(floorNames[state.floor]||'Alle Stockwerke'));
}

function makeText(text,width=1024,height=256){
 const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
 const material=new THREE.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false,toneMapped:false});
 const mesh=new THREE.Mesh(new THREE.PlaneGeometry(1,1),material);
 mesh.userData.canvas=canvas;mesh.userData.texture=texture;paintText(mesh,text);return mesh;
}

function paintText(mesh,text,active=false){
 const canvas=mesh.userData.canvas,ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
 ctx.clearRect(0,0,w,h);ctx.fillStyle=active?'#e5ce44':'#153455';
 ctx.beginPath();ctx.roundRect(0,0,w,h,24);ctx.fill();
 ctx.fillStyle=active?'#152e42':'#ffffff';ctx.textAlign='center';ctx.textBaseline='middle';
 const lines=String(text).split('\n');ctx.font=(lines.length>1?'600 45px':'600 54px')+' system-ui,sans-serif';
 lines.forEach((line,i)=>ctx.fillText(line,w/2,h/2+(i-(lines.length-1)/2)*58,w-50));
 mesh.userData.texture.needsUpdate=true;
}

function clearLabels(){
 for(const label of labels){label.removeFromParent();label.geometry.dispose();label.material.map.dispose();label.material.dispose();}
 labels=[];
}

function updateLabels(){
 clearLabels();if(!world||state.mode!=='model')return;
 const candidates=state.floor==='all'?[selectedRoom()].filter(Boolean):available.filter(r=>r.storey===state.floor);
 for(const room of candidates.slice(0,25)){
  const center=room.center;if(!Array.isArray(center))continue;
  const label=makeText(roomLabel(room),768,160);label.scale.set(6.5,1.35,1);
  label.position.set(center[0],Number(room.level_m??room.z_m)+1.45,center[2]);
  label.rotation.x=-Math.PI/3;world.add(label);labels.push(label);
 }
}

function updateVisibility(){
 for(const mesh of meshes)mesh.visible=isGroupVisible(mesh.userData.vr,state.floor,{roofs:false});
 updateLabels();
}

function updateMarker(){
 if(!marker||!state.ready)return;
 try{
  const spawn=getRoomSpawn(selectedRoom(),routes);
  marker.position.set(spawn.position[0],spawn.position[1]+.035,spawn.position[2]);marker.visible=true;
 }catch{marker.visible=false;}
}

function resetTableCamera(){
 rig.position.set(0,0,0);rig.rotation.set(0,0,0);
 camera.position.set(2.5,2.15,2.3);camera.rotation.set(0,0,0);
 controls.target.set(0,1,-1.5);controls.update();
}

function applyMode({reset=true}={}){
 if(!state.ready)return;
 const room=selectedRoom();let spawn;
 if(state.mode==='room'){
  try{spawn=getRoomSpawn(room,routes);}catch(error){announce(error.message);state.mode='model';}
 }
 if(state.mode==='room'){
  state.floor=room.storey;dom.floor.value=state.floor;
  world.scale.setScalar(1);world.position.set(0,0,0);world.rotation.set(0,0,0);
  if(reset){
   rig.position.fromArray(spawn.position);
   rig.position.y+=state.xr&&state.referenceSpaceType==='local'?1.6:0;
   rig.rotation.set(0,spawn.yaw,0);
   if(state.xr)recenterPending=true;
   else{camera.position.set(0,1.6,0);camera.rotation.set(0,0,0);}
  }
  table.visible=false;environment.visible=false;
 }else{
  const center=sourceBounds.getCenter(new THREE.Vector3());
  world.scale.setScalar(tableScale);world.rotation.set(0,0,0);
  world.position.set(-center.x*tableScale,.82-sourceBounds.min.y*tableScale,-1.5-center.z*tableScale);
  table.visible=true;environment.visible=true;
  if(reset){
   if(state.xr){rig.position.set(0,state.referenceSpaceType==='local'?1.6:0,0);rig.rotation.set(0,0,0);recenterPending=true;}
   else resetTableCamera();
  }
 }
 controls.enabled=!state.xr&&state.mode==='model';
 camera.near=state.mode==='model'?.01:.035;camera.far=250;camera.updateProjectionMatrix();
 updateVisibility();updateMarker();syncUI();
}

function chooseRoom(id){
 const room=available.find(room=>room.id===id);if(!room)return;
 state.roomId=id;state.floor=room.storey;syncChoices();applyMode();
 announce(roomLabel(room)+' ausgewählt.');
}

function chooseFloor(storey){
 state.floor=storey;syncChoices();applyMode();announce((floorNames[storey]||'Alle Stockwerke')+' geöffnet.');
}

function nextRoom(direction){
 const choices=roomChoices();if(!choices.length)return;
 const i=Math.max(0,choices.findIndex(room=>room.id===state.roomId));chooseRoom(choices[(i+direction+choices.length)%choices.length].id);
}

function setMenuVisible(visible){
 state.menuOpen=Boolean(visible);
 if(menu)menu.visible=state.xr&&state.menuOpen;
}

function resetView(){setMenuVisible(true);applyMode();}

function createMenu(){
 menu=new THREE.Group();menu.name='quest-menu';menu.visible=false;rig.add(menu);
 menuTitle=makeText('Schulmodell wird geladen …',1024,220);menuTitle.scale.set(1.72,.30,1);menuTitle.position.set(0,.35,0);menu.add(menuTitle);
 function button(text,x,y,w,action){
  const mesh=makeText(text,640,160);mesh.scale.set(w,.15,1);mesh.position.set(x,y,.005);
  mesh.userData.action=action;mesh.userData.text=text;menu.add(mesh);menuButtons.push(mesh);return mesh;
 }
 ['EG','1OG','2OG','all'].forEach((floor,i)=>button(floor==='all'?'Alle':floor==='1OG'?'1. OG':floor==='2OG'?'2. OG':'EG',(i-1.5)*.435,.10,.405,()=>chooseFloor(floor)));
 button('Tischmodell',-.44,-.095,.84,()=>{state.mode='model';applyMode();});
 button('Im Schulhaus',.44,-.095,.84,()=>{state.mode='room';applyMode();});
 button('Raum zurück',-.58,-.29,.55,()=>nextRoom(-1));
 button('Raum weiter',0,-.29,.55,()=>nextRoom(1));
 button('Neu ausrichten',.58,-.29,.55,resetView);
 button('VR beenden',0,-.49,1.1,()=>session?.end().catch(error=>fail('VR konnte nicht beendet werden. Bitte das Brillenmenü verwenden.',error)));
 button('Menü ausblenden',0,-.69,1.1,()=>setMenuVisible(false));
}

function controllerRay(controller){
 controller.updateWorldMatrix(true,false);rotation.identity().extractRotation(controller.matrixWorld);
 raycaster.ray.origin.setFromMatrixPosition(controller.matrixWorld);
 raycaster.ray.direction.set(0,0,-1).applyMatrix4(rotation).normalize();
}

function controllerSelect(controller){
 if(!state.xr||!state.ready)return;
 controllerRay(controller);
 const hit=menu.visible?raycaster.intersectObjects(menuButtons,false)[0]:null;
 if(hit){hit.object.userData.action();return;}
 if(state.mode!=='model')return;
 const floorHit=raycaster.intersectObjects(floorMeshes.filter(mesh=>mesh.visible),false)[0];
 if(!floorHit)return;
 point.copy(floorHit.point);world.worldToLocal(point);
 const storey=state.floor==='all'?'all':state.floor;
 const room=pickRoomAt(rooms,[point.x,point.y,point.z],storey);
 if(room&&available.some(candidate=>candidate.id===room.id))chooseRoom(room.id);
}

function createControllers(){
 const lineGeometry=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3(0,0,-1)]);
 for(let i=0;i<2;i++){
  const controller=renderer.xr.getController(i),line=new THREE.Line(lineGeometry,new THREE.LineBasicMaterial({color:0xe9d747}));
  line.scale.z=5;controller.add(line);controller.userData.ray=line;rig.add(controller);
  controller.addEventListener('select',()=>controllerSelect(controller));
  controller.addEventListener('squeezestart',()=>{if(state.xr)setMenuVisible(!state.menuOpen);});
  controllers.push(controller);
  const grip=renderer.xr.getControllerGrip(i);
  const body=new THREE.Mesh(new THREE.CapsuleGeometry(.025,.10,3,6),new THREE.MeshBasicMaterial({color:0x447e87}));
  body.rotation.x=-.4;grip.add(body);rig.add(grip);
 }
}

function updateXRMenu(){
 if(!state.xr)return;
 // Keep the entire menu with the player rig and near the current head position.
 // It follows yaw only, so the user can aim at a stable, upright panel.
 camera.getWorldPosition(headPosition);rig.worldToLocal(headPosition);
 camera.getWorldDirection(headForward);headForward.applyQuaternion(rig.quaternion.clone().invert());headForward.y=0;
 if(headForward.lengthSq()<.001)headForward.set(0,0,-1);headForward.normalize();
 menu.position.copy(headPosition).addScaledVector(headForward,1.7);menu.position.y=headPosition.y+.35;
 menu.rotation.set(0,Math.atan2(-headForward.x,-headForward.z),0);
 for(const controller of controllers){
  controllerRay(controller);const hit=menu.visible?raycaster.intersectObjects(menuButtons,false)[0]:null;
  controller.userData.ray.scale.z=hit?Math.min(5,hit.distance):5;
  controller.userData.ray.material.color.setHex(hit?0xffffff:0xe9d747);
 }
}

function recenterXR(){
 if(!state.xr||!recenterPending||!renderer.xr.isPresenting)return;
 // A local-floor origin is not necessarily beneath the person, and their
 // initial yaw is not necessarily north. Cancel that pose with the rig rather
 // than moving the headset camera, keeping the tabletop in front of them.
 renderer.xr.updateCamera(camera);
 const localHead=camera.position.clone();
 const facing=new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
 const localYaw=Math.atan2(-facing.x,-facing.z);
 let target=[0,0,0],yaw=0;
 if(state.mode==='room'){
  const spawn=getRoomSpawn(selectedRoom(),routes);target=spawn.position;yaw=spawn.yaw;
 }
 rig.rotation.set(0,yaw-localYaw,0);
 const headOffset=new THREE.Vector3(localHead.x,0,localHead.z).applyQuaternion(rig.quaternion);
 rig.position.set(target[0]-headOffset.x,target[1]+(state.referenceSpaceType==='local'?1.6:0),target[2]-headOffset.z);
 rig.updateMatrixWorld(true);recenterPending=false;
}

function captureDesktop(){
 return {mode:state.mode,floor:state.floor,roomId:state.roomId,
  rigPosition:rig.position.clone(),rigQuaternion:rig.quaternion.clone(),
  cameraPosition:camera.position.clone(),cameraQuaternion:camera.quaternion.clone(),target:controls.target.clone()};
}

function restoreDesktop(){
 const saved=state.desktop;state.desktop=null;
 if(saved){
  state.mode=saved.mode;state.floor=saved.floor;state.roomId=saved.roomId;syncChoices();applyMode();
  rig.position.copy(saved.rigPosition);rig.quaternion.copy(saved.rigQuaternion);
  camera.position.copy(saved.cameraPosition);camera.quaternion.copy(saved.cameraQuaternion);controls.target.copy(saved.target);
  if(state.mode==='model')controls.update();
 }else applyMode();
 resize();syncUI();
}

async function enterVR(){
 if(state.xr){try{await session?.end();}catch(error){fail('VR konnte nicht beendet werden. Bitte das Brillenmenü verwenden.',error);}return;}
 if(!state.ready||state.starting||!state.supported)return;
 state.desktop=captureDesktop();state.starting=true;syncUI();announce('Bitte den VR-Start in der Brille bestätigen.');
 try{
  // requestVR calls requestSession immediately, within this direct user action.
  const result=await requestVR({xr:navigator.xr,manager:renderer.xr});
  session=result.session;state.referenceSpaceType=result.referenceSpaceType;state.xr=true;state.starting=false;
  setMenuVisible(true);controls.enabled=false;applyMode();announce('VR ist geöffnet. Mit dem Controller auf das Menü oder einen Raum zeigen und den Trigger drücken.');syncUI();
 }catch(error){
  state.xr=false;state.starting=false;session=null;setMenuVisible(true);restoreDesktop();
  announce(error.message||'Die VR-Ansicht konnte nicht gestartet werden. Bitte erneut versuchen.');syncUI();
 }
}

function resize(){
 if(!renderer||state.xr)return;
 const width=Math.max(1,dom.stage.clientWidth),height=Math.max(1,dom.stage.clientHeight);
 camera.aspect=width/height;camera.updateProjectionMatrix();renderer.setSize(width,height);
}

async function json(url){const response=await fetch(url);if(!response.ok)throw new Error('Modelldaten fehlen.');return response.json();}

function loadWithTimeout(promise){let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Das Laden dauert zu lange. Bitte die Verbindung prüfen und erneut laden.')),30000);})]).finally(()=>clearTimeout(timer));}

async function boot(){
 renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.25));renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.92;
 renderer.xr.enabled=true;renderer.xr.setFramebufferScaleFactor(.9);renderer.xr.setFoveation(1);
 dom.stage.append(renderer.domElement);
 scene=new THREE.Scene();scene.background=new THREE.Color(0xe9f0f1);
 rig=new THREE.Group();scene.add(rig);camera=new THREE.PerspectiveCamera(50,1,.01,250);rig.add(camera);
 controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.08;
 controls.minDistance=.7;controls.maxDistance=8;controls.maxPolarAngle=Math.PI*.48;controls.enablePan=false;
 scene.add(new THREE.HemisphereLight(0xffffff,0x6d8c89,2));
 const sunlight=new THREE.DirectionalLight(0xffffff,2.3);sunlight.position.set(3,7,4);scene.add(sunlight);
 world=new THREE.Group();world.name='school-world';scene.add(world);
 table=new THREE.Mesh(new THREE.CylinderGeometry(1.5,1.5,.045,64),new THREE.MeshStandardMaterial({color:0xc7d5d3,roughness:1}));
 table.position.set(0,.785,-1.5);scene.add(table);
 environment=new THREE.GridHelper(12,24,0xb1c5c6,0xd0ddde);scene.add(environment);
 marker=new THREE.Mesh(new THREE.RingGeometry(.65,.82,32),new THREE.MeshBasicMaterial({color:0xe3c840,side:THREE.DoubleSide,transparent:true,opacity:.9,depthWrite:false}));
 marker.rotation.x=-Math.PI/2;marker.visible=false;world.add(marker);
 createMenu();createControllers();
 renderer.xr.addEventListener('sessionend',()=>{
  session=null;state.xr=false;state.starting=false;state.referenceSpaceType='local-floor';setMenuVisible(true);recenterPending=false;
  restoreDesktop();announce('VR beendet. Die 3D-Vorschau ist wieder geöffnet.');
 });
 renderer.domElement.addEventListener('webglcontextlost',event=>{
  event.preventDefault();contextLost=true;state.ready=false;
  fail('Die 3D-Darstellung wurde unterbrochen. Bitte die Ansicht neu laden.');syncUI();
  session?.end().catch(()=>{});
 });
 dom.enter.addEventListener('click',enterVR);
 dom.model.addEventListener('click',()=>{state.mode='model';applyMode();});
 dom.room.addEventListener('click',()=>{state.mode='room';applyMode();});
 dom.floor.addEventListener('change',()=>chooseFloor(dom.floor.value));
 dom.rooms.addEventListener('change',()=>chooseRoom(dom.rooms.value));
 dom.reset.addEventListener('click',resetView);
 let drag=null;
 renderer.domElement.addEventListener('pointerdown',event=>{
  if(state.mode==='room'&&!state.xr)drag={x:event.clientX,y:event.clientY,yaw:rig.rotation.y,pitch:camera.rotation.x};
 });
 renderer.domElement.addEventListener('pointermove',event=>{
  if(!drag||state.xr)return;
  rig.rotation.y=drag.yaw-(event.clientX-drag.x)*.004;
  camera.rotation.x=THREE.MathUtils.clamp(drag.pitch-(event.clientY-drag.y)*.004,-1.2,1.2);
 });
 for(const event of ['pointerup','pointercancel','pointerleave'])renderer.domElement.addEventListener(event,()=>{drag=null;});
 new ResizeObserver(resize).observe(dom.stage);window.addEventListener('resize',resize);
 renderer.setAnimationLoop(()=>{if(state.xr){recenterXR();updateXRMenu();}else if(state.mode==='model')controls.update();renderer.render(scene,camera);});
 resetTableCamera();resize();syncUI();
 probeVR({xr:navigator.xr,secureContext:window.isSecureContext,timeoutMs:4000}).then(result=>{
  state.supported=result.supported;dom.support.textContent=result.message;syncUI();
 }).catch(()=>{state.supported=false;dom.support.textContent='Für VR diesen Link direkt im Meta Quest Browser öffnen.';syncUI();});
 announce('Schulmodell wird geladen …');dom.progress.max=1;dom.progress.removeAttribute('value');
 const loader=new GLTFLoader();
 const [gltf,vrInfo,report,routeData]=await loadWithTimeout(Promise.all([
  loader.loadAsync('./assets/vr-school.glb?v=87e251d52b6e',event=>{if(event.total>0)dom.progress.value=event.loaded/event.total;}),
  json('./assets/vr-school.json?v=3e4d5cbdbb3a'),json('./assets/Gesamtmodell_Quellenabgleich.json?v=fe8332a745e8'),json('./assets/entrance-routes.json?v=ecb6455bd3df')
 ]));
 model=gltf.scene;metadata=vrInfo.groups||{};routes=routeData;
 rooms=(report.rooms||[]).filter(room=>floorNames[room.storey]);
 available=rooms.filter(room=>{
  const name=[room.display_name||room.name||room.id,room.usage||''].join(' ');
  if(room.id==='Pausenhalle_E_50')return true;
  if(/(^|\W)wc(\W|$)|toilet|flur|treppen|windfang|eingang|pausenverkauf/i.test(name))return false;
  try{getRoomSpawn(room,routes);return true;}catch{return false;}
 }).sort((a,b)=>['EG','1OG','2OG'].indexOf(a.storey)-['EG','1OG','2OG'].indexOf(b.storey)||roomLabel(a).localeCompare(roomLabel(b),'de',{numeric:true}));
 if(!available.length)throw new Error('Keine begehbaren Räume verfügbar.');
 const preparedMaterials=new Set();
 model.traverse(object=>{
  if(!object.isMesh)return;
  // The source guide renders both sides of architectural surfaces. Preserve
  // that appearance while retaining the batched model's shared materials.
  for(const material of (Array.isArray(object.material)?object.material:[object.material])){
   if(preparedMaterials.has(material))continue;preparedMaterials.add(material);
   material.side=THREE.DoubleSide;
   if('metalness'in material)material.metalness=0;
   if('roughness'in material)material.roughness=.85;
   material.needsUpdate=true;
  }
  object.userData.vr=metadata[object.name]||object.geometry.userData||{};
  meshes.push(object);if(object.userData.vr.kind==='floor')floorMeshes.push(object);
 });
 if(!meshes.length)throw new Error('Das Modell enthält keine sichtbaren Flächen.');
 world.add(model);sourceBounds=new THREE.Box3(new THREE.Vector3(...vrInfo.bounds.min),new THREE.Vector3(...vrInfo.bounds.max));
 const size=sourceBounds.getSize(new THREE.Vector3());tableScale=2.2/Math.max(size.x,size.z);
 state.ready=true;syncChoices();applyMode();dom.progress.hidden=true;announce('Modell bereit. Einen Raum auswählen oder das Tischmodell erkunden.');
}

boot().catch(error=>{state.ready=false;fail(error.message?.startsWith('Das Laden dauert')?error.message:'Die 3D-Ansicht konnte nicht geladen werden. Bitte erneut versuchen.',error);syncUI();});
