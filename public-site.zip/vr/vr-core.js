// Shared VR decisions are independent of DOM, rendering and headset hardware.
const STOREYS = new Set(['EG', '1OG', '2OG']);

function deadline(promise, milliseconds) {
 let timer;
 return Promise.race([
  Promise.resolve(promise),
  new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('timeout')), milliseconds); })
 ]).finally(() => clearTimeout(timer));
}

export async function probeVR({xr, secureContext = true, timeoutMs = 4000} = {}) {
 if (!secureContext) return {supported:false, reason:'https', message:'VR benötigt einen sicheren HTTPS-Link. Bitte den veröffentlichten Link öffnen.'};
 if (!xr || typeof xr.requestSession !== 'function') return {supported:false, reason:'unavailable', message:'Hier ist die 3D-Vorschau geöffnet. Für VR diesen Link im Browser der Meta Quest öffnen.'};
 if (typeof xr.isSessionSupported !== 'function') return {supported:true, reason:'direct', message:'Die Brille ist bereit. Mit „VR starten“ öffnen.'};
 try {
  const supported = await deadline(xr.isSessionSupported('immersive-vr'), timeoutMs);
  return supported
   ? {supported:true, reason:'supported', message:'VR ist verfügbar. Mit „VR starten“ in die Brille wechseln.'}
   : {supported:false, reason:'unsupported', message:'Dieser Browser bietet gerade keinen VR-Modus an. Bitte den Link direkt im Meta Quest Browser öffnen.'};
 } catch {
  // A capability check must never leave a usable headset permanently blocked.
  return {supported:true, reason:'check-unavailable', message:'Die automatische Prüfung ist nicht abgeschlossen. „VR starten“ versucht den Einstieg direkt.'};
 }
}

function sessionError(error) {
 const messages = {
  NotAllowedError:'Der VR-Start wurde nicht freigegeben. Bitte in der Brille bestätigen und erneut „VR starten“ wählen.',
  SecurityError:'VR ist hier gesperrt. Bitte die HTTPS-Seite direkt im Meta Quest Browser öffnen.',
  NotSupportedError:'Dieser Browser stellt keinen immersiven VR-Modus bereit. Bitte den Meta Quest Browser verwenden.',
  InvalidStateError:'Eine andere VR-Ansicht ist bereits aktiv. Diese zuerst schließen und erneut starten.',
 };
 const result = new Error(messages[error?.name] || 'Die VR-Ansicht konnte nicht gestartet werden. Bitte erneut versuchen.');
 result.code = error?.name || 'XRSessionError';
 result.cause = error;
 return result;
}

export async function requestVR({xr, manager} = {}) {
 if (!xr || typeof xr.requestSession !== 'function' || !manager) throw sessionError({name:'NotSupportedError'});
 const existing = manager.getSession?.();
 if (existing) return {session:existing, referenceSpaceType:manager.getReferenceSpaceType?.() || 'local-floor'};
 let session;
 try {
  // Deliberately the first asynchronous operation: retain the click's activation.
  session = await xr.requestSession('immersive-vr', {optionalFeatures:['local-floor']});
  let referenceSpaceType = 'local-floor';
  try { await session.requestReferenceSpace('local-floor'); }
  catch { referenceSpaceType = 'local'; }
  manager.setReferenceSpaceType(referenceSpaceType);
  await manager.setSession(session);
  return {session, referenceSpaceType};
 } catch (error) {
  if (session) { try { await session.end(); } catch {} }
  throw sessionError(error);
 }
}

export function containsPoint2D(polygon, x, y) {
 if (!Array.isArray(polygon) || polygon.length < 3 || !Number.isFinite(x) || !Number.isFinite(y)) return false;
 let inside = false;
 for (let i=0,j=polygon.length-1; i<polygon.length; j=i++) {
  const [xi,yi] = polygon[i], [xj,yj] = polygon[j];
  if ((yi>y)!==(yj>y) && x<(xj-xi)*(y-yi)/(yj-yi)+xi) inside = !inside;
 }
 return inside;
}

export function pickRoomAt(rooms, point, storey = 'all') {
 const [x,y,z] = Array.isArray(point) ? point : [point?.x,point?.y,point?.z];
 if (![x,y,z].every(Number.isFinite)) return null;
 return rooms.filter(room => STOREYS.has(room.storey) &&
  (storey==='all' || room.storey===storey) &&
  containsPoint2D(room.polygon_xy_m,x,-z) &&
  !(room.holes_xy_m||[]).some(hole => containsPoint2D(hole,x,-z)))
  .sort((a,b) => Math.abs(y-Number(a.level_m??a.z_m))-Math.abs(y-Number(b.level_m??b.z_m)))[0] || null;
}

export function getRoomSpawn(room, routes) {
 if (!room) throw new Error('Bitte zuerst einen Raum auswählen.');
 const level = Number(room.level_m ?? room.z_m);
 if (!Number.isFinite(level)) throw new Error('Für diesen Raum fehlt die Höhe im Modell.');
 const candidates = Object.values(routes?.routes || {}).map(paths => paths?.[room.id]?.points3D?.at(-1))
  .filter(p => Array.isArray(p) && p.length===3 && p.every(Number.isFinite) &&
   containsPoint2D(room.polygon_xy_m,p[0],-p[2]) &&
   !(room.holes_xy_m||[]).some(hole => containsPoint2D(hole,p[0],-p[2])));
 if (!candidates.length) throw new Error('Für diesen Raum ist noch kein freier Einstiegspunkt im Modell vorhanden. Bitte einen anderen Raum wählen.');
 const point = candidates[0];
 const center = room.center || point;
 const dx = Number(center[0])-point[0], dz = Number(center[2])-point[2];
 return {position:[point[0],level,point[2]], yaw:Math.hypot(dx,dz)>0.05?Math.atan2(-dx,-dz):0};
}

export function isGroupVisible(meta, storey = 'EG', {roofs = false} = {}) {
 if (!meta || meta.kind==='support' || meta.exterior_platform) return false;
 if (meta.kind==='roof' && !roofs) return false;
 const levels = (meta.effective_storeys || meta.visible_storeys || [meta.storey]).filter(s => STOREYS.has(s));
 return storey==='all' ? levels.length>0 : levels.includes(storey);
}
