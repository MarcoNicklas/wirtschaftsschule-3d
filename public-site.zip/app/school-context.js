import * as THREE from 'three';

// The adjacent building is orientation context, never a room or route target.
export function contextVisibility({whole, floor, exploded, route, roofs}) {
 const enabled=whole&&!route;
 const exterior=enabled&&floor==='all'&&!exploded;
 return {exterior, connection:enabled&&(floor==='all'||floor==='storey:1OG'), roof:exterior&&roofs};
}

export function createSchoolContext(scene, loader, assetUrl) {
 let root=null, pending=null, state=null;
 async function load() {
  if(root)return root;
  if(pending)return pending;
  pending=loader.loadAsync(assetUrl).then(gltf=>{
   root=gltf.scene;root.name='Berufsschulgebäude';root.visible=false;
   root.traverse(o=>{
    if(!o.isMesh)return;
    const kind=o.userData.kind;
    o.userData.basePosition=o.position.clone();
    const materials=(Array.isArray(o.material)?o.material:[o.material]).map(source=>{
     const mat=source.clone();mat.vertexColors=false;mat.metalness=0;mat.roughness=.85;mat.side=THREE.DoubleSide;
     mat.color.set(kind==='connection_ground'?0x636b6d:kind==='connection_support'?0xc3beae:kind==='connection_roof'?(o.name.includes('Attika')?0xc2c5bc:0xb2b5ab):kind==='context_roof'?0x7c827d:kind==='context_glass'?0x475b62:kind==='context_window'?(o.name.includes('Sims')?0xb6b7ac:0x4c5759):0xd6d1c1);
     if(kind==='context_glass'){mat.transparent=true;mat.opacity=.8;mat.depthWrite=false;mat.roughness=.35;}
     return mat;
    });o.material=materials.length===1?materials[0]:materials;
   });scene.add(root);return root;
  }).catch(error=>{pending=null;throw error;});
  return pending;
 }
 function update(options) {
  state=contextVisibility(options);
  if(!root)return false;
  root.visible=state.exterior||state.connection;
  root.traverse(o=>{
   if(!o.isMesh)return;
   const kind=o.userData.kind;
   o.visible=kind==='connection_floor'?state.connection:kind==='connection_roof'?state.roof:state.exterior;
   o.position.copy(o.userData.basePosition);
   if(kind==='connection_floor')o.position.y+=options.offset(1.55);
  });
  root.updateMatrixWorld(true);
  return state.roof;
 }
 function visibleMeshes() {
  const meshes=[];
  root?.traverseVisible(o=>{if(o.isMesh)meshes.push(o);});
  return meshes;
 }
 return {load,update,visibleMeshes,get exteriorVisible(){return Boolean(root?.visible&&state?.exterior);}};
}
