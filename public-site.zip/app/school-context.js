import * as THREE from 'three';

const roofKinds=new Set(['connection_roof','context_roof','workshop_roof','solar_panel','solar_frame','solar_cells','solar_support']);
const unframedKinds=new Set(['terrain','ground','campus_ground','base']);
// The campus is orientation context, never a room or route target.
export function contextVisibility({whole, floor, exploded, route, roofs}) {
 const enabled=whole&&!route;
 const exterior=enabled&&floor==='all'&&!exploded;
 return {exterior, connection:enabled&&(floor==='all'||floor==='storey:1OG'), roof:exterior&&roofs};
}

export function createSchoolContext(scene, loader, assetUrl) {
 let root=null, pending=null, state=null;
 async function load() {
  if(root)return root;
  if(pending)return pending;
  pending=loader.loadAsync(assetUrl).then(gltf=>{
   root=gltf.scene;root.name='Schulgelände';root.visible=false;
   root.traverse(o=>{
    if(!o.isMesh)return;
    const kind=o.userData.kind;
    o.userData.basePosition=o.position.clone();
    const materials=(Array.isArray(o.material)?o.material:[o.material]).map(source=>{
     const mat=source.clone();mat.metalness=0;mat.roughness=.85;mat.side=THREE.DoubleSide;
     if(o.geometry.attributes.color)mat.color.set(0xffffff);
     const contextBuilding=String(kind).startsWith('context_')||String(kind).startsWith('workshop')||o.name.startsWith('Werkstatt_Rote_Wand')||o.name.startsWith('Berufsschulsockel');
     if(contextBuilding){
      mat.vertexColors=false;mat.color.set(/roof/.test(kind)?0xa9bdc4:0xbdcdd1);
      mat.transparent=false;mat.opacity=1;mat.depthWrite=true;mat.side=THREE.FrontSide;
     }else if(['terrain','base'].includes(kind)){
      mat.vertexColors=false;mat.color.set(0xc2d6d4);mat.roughness=1;
      mat.transparent=false;mat.opacity=1;mat.depthWrite=true;mat.side=THREE.FrontSide;
     }else if(kind==='connection_roof'){
      mat.vertexColors=false;mat.color.set(o.name.includes('Attika')?0xe5e2d4:0x3d5051);mat.roughness=.78;
     }else if(kind==='solar_panel'){
      mat.vertexColors=false;mat.color.set(0x143d63);mat.metalness=.25;mat.roughness=.28;
      mat.polygonOffset=true;mat.polygonOffsetFactor=-1;mat.polygonOffsetUnits=-1;
     }else if(kind==='solar_cells'){
      mat.polygonOffset=true;mat.polygonOffsetFactor=-2;mat.polygonOffsetUnits=-2;
     }else if(kind==='solar_frame'||kind==='solar_support'){
      mat.metalness=.55;mat.roughness=.38;
     }else if(['plant','tree'].includes(kind)){
      mat.vertexColors=false;mat.color.set(/Stamm|Ast/.test(o.name)?0x755c41:0x4f803c);mat.roughness=1;
     }else if(kind==='planting_bed'){
      mat.vertexColors=false;mat.color.set(0x78965c);mat.roughness=1;
     }else if(/steel|metal/i.test(String(kind))){mat.metalness=.25;mat.roughness=.6;}
     return mat;
    });o.material=materials.length===1?materials[0]:materials;
   });scene.add(root);return root;
  }).catch(error=>{pending=null;throw error;});
  return pending;
 }
 function update(options) {
  state=contextVisibility(options);
  if(!root)return false;
  root.visible=state.exterior||state.connection;
  root.traverse(o=>{
   if(!o.isMesh)return;
   const kind=o.userData.kind;
   o.visible=kind==='connection_floor'?state.connection:roofKinds.has(kind)?state.roof:state.exterior;
   o.position.copy(o.userData.basePosition);
   if(kind==='connection_floor')o.position.y+=options.offset(1.55);
  });
  root.updateMatrixWorld(true);
  return state.roof;
 }
 function visibleMeshes() {
  const meshes=[];
  // The presentation ground must not shrink the buildings during auto-framing.
  root?.traverseVisible(o=>{if(o.isMesh&&!unframedKinds.has(o.userData.kind))meshes.push(o);});
  return meshes;
 }
 return {load,update,visibleMeshes,get exteriorVisible(){return Boolean(root?.visible&&state?.exterior);}};
}
