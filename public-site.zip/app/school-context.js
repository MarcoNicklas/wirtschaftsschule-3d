import * as THREE from 'three';

// The adjacent building is orientation context, never a room or route target.
export function contextVisibility({whole, floor, exploded, route, roofs}) {
 const enabled=whole&&!route;
 const exterior=enabled&&floor==='all'&&!exploded;
 return {exterior, connection:enabled&&(floor==='all'||floor==='storey:1OG'), roof:exterior&&roofs};
}

export function createSchoolContext(scene, loader, assetUrl) {
 let root=null, pending=null, state=null;
 async function load() {
  if(root)return root;
  if(pending)return pending;
  pending=loader.loadAsync(assetUrl).then(gltf=>{
   root=gltf.scene;root.name='Berufsschulgebäude';root.visible=false;
   root.traverse(o=>{
    if(!o.isMesh)return;
    const kind=o.userData.kind;
    o.userData.basePosition=o.position.clone();
    const materials=(Array.isArray(o.material)?o.material:[o.material]).map(source=>{
     const mat=source.clone();mat.vertexColors=false;mat.metalness=0;mat.roughness=.85;mat.side=THREE.DoubleSide;
     // Pale neutral context lets the school's green facade remain the focal point.
     mat.color.set(['campus_ground','campus_base','connection_ground'].includes(kind)?0xb5b9bb:kind==='connection_support'?0xc3beae:kind==='connection_roof'?(o.name.includes('Attika')?0xc2c5bc:0xb2b5ab):kind==='context_roof'?0xc9ced1:kind==='context_glass'?0xb1bcc4:kind==='context_window'?0xc5ccd0:0xdce0e2);
     if(kind==='context_glass'){mat.transparent=false;mat.opacity=1;mat.depthWrite=true;mat.roughness=.85;}
     return mat;
    });o.material=materials.length===1?materials[0]:materials;
   });scene.add(root);return root;
  }).catch(error=>{pending=null;throw error;});
  return pending;
 }
 function update(options) {
  state=contextVisibility(options);
  if(!root)return false;
  root.visible=state.exterior||state.connection;
  root.traverse(o=>{
   if(!o.isMesh)return;
   const kind=o.userData.kind;
   o.visible=kind==='connection_floor'?state.connection:kind==='connection_roof'?state.roof:state.exterior;
   o.position.copy(o.userData.basePosition);
   if(kind==='connection_floor')o.position.y+=options.offset(1.55);
  });
  root.updateMatrixWorld(true);
  return state.roof;
 }
 function visibleMeshes() {
  const meshes=[];
  // The presentation ground must not shrink the buildings during auto-framing.
  root?.traverseVisible(o=>{if(o.isMesh&&o.userData.kind!=='campus_ground')meshes.push(o);});
  return meshes;
 }
 return {load,update,visibleMeshes,get exteriorVisible(){return Boolean(root?.visible&&state?.exterior);}};
}
