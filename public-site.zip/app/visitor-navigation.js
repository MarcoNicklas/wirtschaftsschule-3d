const FLOORS={EG:'Erdgeschoss','1OG':'1. Obergeschoss','2OG':'2. Obergeschoss'};
export function isSelectableRoom(room){
 const name=[room.id,room.display_name,room.source_name,room.name,room.usage].filter(Boolean).join(' ');
 return Boolean(FLOORS[room.storey])&&!/(^|[^a-z])wc([^a-z]|$)|toilet|sanitär|sanitaer|aula|pausenhalle|pausenverkauf|eingang|windfang|flur|treppenhaus|corridor/i.test(name);
}
export function validatedAssignments(config,rooms){
 const ids=new Set(rooms.map(r=>r.id));const event=config.parentsEvening;
 if(!event||!/^\d{4}-\d{2}-\d{2}$/.test(event.date??'')||!Array.isArray(event.assignments))return [];
 const date=new Date(event.date+'T12:00:00Z');if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==event.date)return [];
 const seen=new Set();return event.assignments.filter(a=>{if(!a||typeof a.teacher!=='string'||!a.teacher.trim()||a.teacher.length>100||!ids.has(a.roomId))return false;const key=a.teacher.trim().toLocaleLowerCase('de');if(seen.has(key))return false;seen.add(key);return true}).map(a=>({teacher:a.teacher.trim(),roomId:a.roomId}));
}
// Trial assignments remain separate from the dated event list.
export function validatedTrialAssignments(config,rooms,routes){
 const trial=config.trialAssignments;
 if(trial?.enabled!==true||!Array.isArray(trial.assignments)||!routes?.entrances?.length)return [];
 const ids=new Set(rooms.filter(isSelectableRoom).map(r=>r.id)),seenTeachers=new Set(),seenRooms=new Set();
 return trial.assignments.filter(a=>{
  if(!a||typeof a.teacher!=='string'||!a.teacher.trim()||a.teacher.length>100||!ids.has(a.roomId))return false;
  const key=a.teacher.trim().toLocaleLowerCase('de');
  if(seenTeachers.has(key)||seenRooms.has(a.roomId)||!routes.entrances.every(e=>routes.routes?.[e.id]?.[a.roomId]?.points3D?.length>1))return false;
  seenTeachers.add(key);seenRooms.add(a.roomId);return true;
 }).map(a=>({teacher:a.teacher.trim(),roomId:a.roomId}));
}
export function teacherAssignmentMode(config,rooms,routes){
 const actual=validatedAssignments(config,rooms.filter(isSelectableRoom));
 if(actual.length)return {assignments:actual,provisional:false};
 return {assignments:validatedTrialAssignments(config,rooms,routes),provisional:true};
}
export function initVisitorNavigation({container,rooms,routes,config={},onFocusRoom,onShow3D,onClearRoute}){
 const roomMap=new Map(rooms.map(r=>[r.id,r]));
 const label=r=>r.display_name||r.source_name||r.name;
 const choices=rooms.filter(isSelectableRoom),choiceIds=new Set(choices.map(r=>r.id));
 let mode='room',selectedId='',teacher='',ready=false;
 const assignmentMode=teacherAssignmentMode(config,choices,routes),teacherList=assignmentMode.assignments,demo=assignmentMode.provisional;
 container.innerHTML='<div class="nav-field"><label class="field-label" for="entrance-choice"><span class="step-number">1</span> Ihr Eingang</label><select id="entrance-choice"></select></div><div class="nav-field"><span class="field-label"><span class="step-number">2</span> Ihr Ziel</span><div class="target-switch" role="group" aria-label="Zielart"><button id="mode-room" aria-pressed="true">Raum</button><button id="mode-teacher" aria-pressed="false">Lehrkraft</button></div><select id="destination-choice" aria-label="Raum auswählen"></select><p id="target-helper" class="target-helper" hidden></p></div><button id="show-way" class="primary-action" disabled><span>Weg anzeigen</span><span aria-hidden="true">↗</span></button><p id="nav-status" class="nav-status" role="status" aria-live="polite"></p>';
 const $=id=>container.querySelector('#'+id),entrance=$('entrance-choice'),destination=$('destination-choice'),status=$('nav-status'),button=$('show-way');
 for(const e of routes.entrances??[])entrance.add(new Option(e.label,e.id));
 if(!entrance.options.length){entrance.add(new Option('Eingänge nicht geladen',''));entrance.disabled=true}
 function path(){return routes.routes?.[entrance.value]?.[selectedId]??null}
 function update(){
  entrance.disabled=!ready||!routes.entrances?.length;destination.disabled=!ready||(mode==='teacher'&&!teacherList.length);
  const r=roomMap.get(selectedId),route=path();document.getElementById('room-route').disabled=!ready||!r||!route;button.disabled=!ready||!r||!route;button.querySelector('span').textContent='Weg anzeigen';
  status.textContent=routes.unavailableData?'Die Wegdaten konnten nicht geladen werden. Bitte laden Sie die Seite erneut.':!ready?'Das Modell wird vorbereitet.':r&&!route?'Der Raum ist im Modell zu sehen. Der Weg von diesem Eingang wird noch ergänzt.':r?(route.segments?.some(s=>s.type==='stairs')?'Der Weg führt über Treppen.':''):'';
 }
 function fill(){
  $('mode-room').setAttribute('aria-pressed',mode==='room');$('mode-teacher').setAttribute('aria-pressed',mode==='teacher');destination.setAttribute('aria-label',mode==='room'?'Raum auswählen':'Lehrkraft auswählen');
  destination.replaceChildren(new Option(mode==='room'?'Raum auswählen …':'Lehrkraft auswählen …',''));
  const helper=$('target-helper');helper.hidden=true;
  if(mode==='room'){
   for(const [floor,name]of Object.entries(FLOORS)){const group=document.createElement('optgroup');group.label=name;choices.filter(r=>r.storey===floor).sort((a,b)=>label(a).localeCompare(label(b),'de',{numeric:true})).forEach(r=>group.append(new Option(label(r),r.id)));if(group.children.length)destination.append(group)}
   destination.disabled=false;destination.value=selectedId;
  }else{
   const list=[...teacherList].sort((a,b)=>a.teacher.localeCompare(b.teacher,'de'));
   for(const a of list)destination.add(new Option(a.teacher+' → '+label(roomMap.get(a.roomId)),a.teacher));
   destination.disabled=!list.length;destination.value=teacher;
   helper.hidden=false;
   helper.textContent=demo&&list.length?'PROBEZUORDNUNG · Nur zum Ausprobieren. Die tatsächlichen Räume werden vor dem Elternsprechtag bekannt gegeben.':!demo?'Raumzuordnung für den Elternsprechtag am '+new Date(config.parentsEvening.date+'T12:00:00').toLocaleDateString('de-DE')+'.':'Die Raumzuordnung wird kurz vor dem Elternsprechtag bekannt gegeben.';
  }update();
 }
 function selectRoom(id,{focus=false}={}){
  if(!roomMap.has(id))return;
  if(!choiceIds.has(id)){mode='room';selectedId='';teacher='';fill();return}
  if(mode==='teacher'&&selectedId===id){update();return}
  mode='room';selectedId=id;teacher='';fill();if(focus)onFocusRoom(id)
 }
 function chooseMode(value){onClearRoute();mode=value;selectedId='';teacher='';fill()}
 $('mode-room').onclick=()=>chooseMode('room');$('mode-teacher').onclick=()=>chooseMode('teacher');
 destination.onchange=()=>{onClearRoute();if(mode==='teacher'){teacher=destination.value;selectedId=teacherList.find(a=>a.teacher===teacher)?.roomId??''}else{selectedId=destination.value;teacher=''}update();if(selectedId)onFocusRoom(selectedId)};
 entrance.onchange=()=>{onClearRoute();update();if(selectedId)onFocusRoom(selectedId)};
 function showSelected(){
  const route=path();if(!ready||!route||!selectedId)return;
  const origin=routes.entrances.find(e=>e.id===entrance.value);
  onShow3D({route,targetId:selectedId,startId:origin.startRoomId,entrance:origin,teacherNames:teacher?[teacher]:[],demo:mode==='teacher'&&demo});
 }
 button.onclick=showSelected;
 const pending=document.getElementById('live-tour-pending'),link=document.getElementById('live-tour-link');
 try{const url=new URL(config.liveTourUrl);if(url.protocol==='https:'){link.href=url.href;link.hidden=false;pending.hidden=true}}catch{}
 fill();
 return{selectRoom,showSelected,setReady(value){ready=value;update()},getSelectedId:()=>selectedId};
}
