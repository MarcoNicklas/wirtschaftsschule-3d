const FLOORS={EG:'Erdgeschoss','1OG':'1. Obergeschoss','2OG':'2. Obergeschoss'};
export function isSelectableRoom(room){
 const name=[room.id,room.display_name,room.source_name,room.name,room.usage].filter(Boolean).join(' ');
 return Boolean(FLOORS[room.storey])&&!/(^|[^a-z])wc([^a-z]|$)|toilet|sanitär|sanitaer|aula|pausenhalle|pausenverkauf|eingang|windfang|flur|treppenhaus|corridor/i.test(name);
}
function datedEvent(config) {
 const event = config?.parentsEvening;
 if (event?.published === true && !event.date && Array.isArray(event.assignments)) return event;
 if (!Array.isArray(event?.assignments) || !/^\d{4}-\d{2}-\d{2}$/.test(event.date)) return null;
 const date = new Date(event.date + 'T12:00:00Z');
 return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === event.date ? event : null;
}

export function validatedAssignments(config, rooms) {
 const event = datedEvent(config);
 if (!event) return [];
 const ids = new Set(rooms.filter(room => FLOORS[room.storey]).map(room => room.id));
 const seen = new Set();
 const result = [];
 for (const row of event.assignments) {
  if (typeof row?.teacher !== 'string') continue;
  const teacher = row.teacher.trim();
  const key = teacher.toLocaleLowerCase('de');
  if (!teacher || teacher.length > 100 || seen.has(key)) continue;
  const roomId = ids.has(row.roomId) ? row.roomId : '';
  const room = String(row.room ?? '').trim();
  let entry;
  if (!row.kind && roomId) {
   entry = {teacher, roomId}; // Historical dated assignments contain only these two fields.
  } else if (row.kind === 'unassigned') {
   entry = {teacher, kind: row.kind};
  } else if (room && ['room', 'unmapped', 'berufsschule'].includes(row.kind)) {
   const kind = row.kind === 'room' && !roomId ? 'unmapped' : row.kind;
   entry = {teacher, room, kind};
   if (kind === 'room') entry.roomId = roomId;
  }
  if (!entry) continue;
  seen.add(key);
  result.push(entry);
 }
 return result;
}

// Trial assignments remain separate from the dated event list.
export function validatedTrialAssignments(config,rooms,routes){
 const trial=config.trialAssignments;
 if(trial?.enabled!==true||!Array.isArray(trial.assignments)||!routes?.entrances?.length)return [];
 const ids=new Set(rooms.filter(isSelectableRoom).map(r=>r.id)),seenTeachers=new Set(),seenRooms=new Set();
 return trial.assignments.filter(a=>{
  if(!a||typeof a.teacher!=='string'||!a.teacher.trim()||a.teacher.length>100||!ids.has(a.roomId))return false;
  const key=a.teacher.trim().toLocaleLowerCase('de');
  if(seenTeachers.has(key)||seenRooms.has(a.roomId)||!routes.entrances.every(e=>routes.routes?.[e.id]?.[a.roomId]?.points3D?.length>1))return false;
  seenTeachers.add(key);seenRooms.add(a.roomId);return true;
 }).map(a=>({teacher:a.teacher.trim(),roomId:a.roomId}));
}
export function teacherAssignmentMode(config, rooms, routes) {
 if (datedEvent(config)) return {assignments: validatedAssignments(config, rooms), provisional: false};
 return {assignments: validatedTrialAssignments(config, rooms, routes), provisional: true};
}

function eventLocation(entry) {
 const location = [entry.kind === 'berufsschule' ? 'Eingang Berufsschule' : '', entry.room && 'Raum ' + entry.room];
 return location.filter(Boolean).join(' · ');
}

function searchName(value) {
 return value.toLocaleLowerCase('de').normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '').replace(/ß/g, 'ss')
  .replace(/ae/g, 'a').replace(/oe/g, 'o').replace(/ue/g, 'u')
  .replace(/[^a-z0-9]/g, '');
}

export function initVisitorNavigation({container, rooms, routes, config = {}, onFocusRoom, onShow3D, onClearRoute}) {
 const roomMap = new Map(rooms.map(room => [room.id, room]));
 const label = room => room?.display_name || room?.source_name || room?.name || '';
 const choices = rooms.filter(isSelectableRoom);
 const choiceIds = new Set(choices.map(room => room.id));
 const {assignments: teacherList, provisional: demo} = teacherAssignmentMode(config, rooms, routes);
 const teachers = new Map(teacherList.map(row => [row.teacher, row]));
 const collator = new Intl.Collator('de', {ignorePunctuation: true});
 const ordered = teacherList.map(entry => {
  const parts = entry.teacher.split(/\s+/);
  const surname = parts.pop();
  const givenNames = parts.join(' ');
  return {entry, surname, givenNames};
 }).sort((a, b) => collator.compare(a.surname, b.surname) || collator.compare(a.givenNames, b.givenNames));
 let mode = 'room', selectedId = '', teacher = '', ready = false, loadError = false;
 container.innerHTML='<div class="nav-field"><label class="field-label" for="entrance-choice"><span class="step-number">1</span> Ihr Eingang</label><select id="entrance-choice"></select></div><div class="nav-field"><span class="field-label"><span class="step-number">2</span> Ihr Ziel</span><div class="target-switch" role="group" aria-label="Zielart"><button id="mode-room" aria-pressed="true">Raum</button><button id="mode-teacher" aria-pressed="false">Lehrkraft</button></div><div id="teacher-search-field" class="teacher-search-field" hidden><label class="field-label" for="teacher-search">Nachname suchen</label><input id="teacher-search" type="search" placeholder="z. B. Schulz" autocomplete="off" spellcheck="false" enterkeyhint="search" aria-controls="destination-choice" aria-describedby="teacher-search-results"><p id="teacher-search-results" class="teacher-search-results" role="status" aria-live="polite"></p></div><select id="destination-choice" aria-label="Raum auswählen"></select><p id="target-helper" class="target-helper" hidden></p></div><button id="show-way" class="primary-action" disabled><span>Weg anzeigen</span><span aria-hidden="true">↗</span></button><p id="nav-status" class="nav-status" role="status" aria-live="polite"></p>';
 const $ = id => container.querySelector('#' + id);
 const entrance = $('entrance-choice'), destination = $('destination-choice'), status = $('nav-status'), button = $('show-way');
 const search = $('teacher-search'), searchResults = $('teacher-search-results');
 for (const e of routes.entrances ?? []) entrance.add(new Option(e.label, e.id));
 if (!entrance.options.length) entrance.add(new Option('Eingänge nicht geladen', ''));
 const selectedTeacher = () => mode === 'teacher' ? teachers.get(teacher) : null;
 const path = () => routes.routes?.[entrance.value]?.[selectedId] ?? null;
 const matchingTeachers = () => {
  const words = search.value.trim().split(/\s+/).map(searchName).filter(Boolean);
  return ordered.filter(({entry}) => words.every(word => searchName(entry.teacher).includes(word)));
 };

 function update() {
  const entry = selectedTeacher(), room = roomMap.get(selectedId), route = path();
  const infoOnly = Boolean(entry && !entry.roomId);
  entrance.parentElement.hidden = infoOnly;
  entrance.disabled = infoOnly || !ready || !routes.entrances?.length;
  destination.disabled = mode === 'teacher' ? !teacherList.length : !ready;
  button.hidden = infoOnly;
  button.disabled = !ready || !room || !route;
  document.getElementById('room-route').disabled = button.disabled;
  const messages = [];
  if (entry) {
   if (entry.room) messages.push(eventLocation(entry) + '.');
   if (entry.kind === 'unassigned') messages.push('Für diese Lehrkraft ist noch kein Raum angegeben.');
   if (entry.kind === 'unmapped') messages.push('Die Lage dieses Raums ist im 3D-Modell noch offen.');
  }
  if (!infoOnly) {
   if (routes.unavailableData) messages.push('Die Wegdaten konnten nicht geladen werden. Bitte laden Sie die Seite erneut.');
   else if (loadError) messages.push('Das 3D-Modell konnte nicht geladen werden. Bitte laden Sie die Seite erneut.');
   else if (!ready) messages.push('Das Modell wird vorbereitet.');
   else if (room && !route) messages.push('Der Weg von diesem Eingang wird noch ergänzt.');
   else if (route?.segments?.some(s => s.type === 'stairs')) messages.push('Der Weg führt über Treppen.');
  }
  status.textContent = messages.join(' ');
 }

 function fill() {
  const byTeacher = mode === 'teacher';
  $('mode-room').setAttribute('aria-pressed', !byTeacher);
  $('mode-teacher').setAttribute('aria-pressed', byTeacher);
  const prompt = byTeacher ? 'Lehrkraft auswählen' : 'Raum auswählen';
  destination.setAttribute('aria-label', prompt);
  destination.replaceChildren(new Option(prompt + ' …', ''));
  const helper = $('target-helper');
  helper.hidden = !byTeacher;
  $('teacher-search-field').hidden = !byTeacher;
  if (byTeacher) {
   const matches = matchingTeachers();
   searchResults.textContent = '';
   if (search.value.trim() && matches.length !== 1) {
    searchResults.textContent = matches.length ? matches.length + ' Lehrkräfte gefunden – bitte auswählen.' : 'Keine Lehrkraft gefunden.';
   }
   for (const {entry, surname, givenNames} of matches) {
    const displayName = givenNames ? surname + ', ' + givenNames : surname;
    const detail = entry.room ? eventLocation(entry) : (label(roomMap.get(entry.roomId)) || 'Raum offen');
    destination.add(new Option(displayName + ' → ' + detail, entry.teacher));
   }
   destination.value = teacher;
   if (!demo) helper.textContent = config.parentsEvening.date ? ('Elternsprechtag am ' + new Date(config.parentsEvening.date + 'T12:00:00').toLocaleDateString('de-DE') + '.') : 'Raumbelegung für den Elternsprechtag.';
   else helper.textContent = teacherList.length ? 'PROBEZUORDNUNG · Nur zum Ausprobieren.' : 'Die Raumzuordnung wird kurz vor dem Elternsprechtag bekannt gegeben.';
  } else {
   for (const [floor, name] of Object.entries(FLOORS)) {
    const group = document.createElement('optgroup');
    group.label = name;
    choices.filter(r => r.storey === floor).sort((a, b) => label(a).localeCompare(label(b), 'de', {numeric: true})).forEach(r => group.append(new Option(label(r), r.id)));
    if (group.children.length) destination.append(group);
   }
   destination.value = selectedId;
  }
  update();
 }
 function selectRoom(id, {focus = false} = {}) {
  if (!roomMap.has(id)) return;
  // A dated event may use a room that has no entry in the regular room picker.
  if (mode === 'teacher' && selectedId === id) { update(); return; }
  mode = 'room';
  selectedId = choiceIds.has(id) ? id : '';
  teacher = '';
  search.value = '';
  fill();
  if (focus && selectedId) onFocusRoom(selectedId);
 }
 function chooseMode(value) {
  onClearRoute(true);
  mode = value;
  selectedId = '';
  teacher = '';
  search.value = '';
  fill();
 }
 $('mode-room').onclick = () => chooseMode('room');
 $('mode-teacher').onclick = () => chooseMode('teacher');
 search.oninput = () => {
  if (mode !== 'teacher') return;
  onClearRoute(true);
  const matches = matchingTeachers();
  teacher = search.value.trim() && matches.length === 1 ? matches[0].entry.teacher : '';
  selectedId = selectedTeacher()?.roomId ?? '';
  fill();
 };
 search.onkeydown = event => {
  if (event.key !== 'Enter' || event.isComposing) return;
  event.preventDefault();
  if (!button.disabled && !button.hidden) {
   search.blur();
   showSelected();
  }
 };
 destination.onchange = () => {
  teacher = mode === 'teacher' ? destination.value : '';
  selectedId = mode === 'teacher' ? (selectedTeacher()?.roomId ?? '') : destination.value;
  onClearRoute(!selectedId);
  update();
  if (selectedId && ready) onFocusRoom(selectedId, {scroll: mode !== 'teacher'});
 };
 entrance.onchange = () => {
  onClearRoute();
  update();
  if (selectedId && ready) onFocusRoom(selectedId, {scroll: mode !== 'teacher'});
 };
 function showSelected() {
  const route = path();
  if (!ready || !route || !selectedId) return;
  const origin = routes.entrances.find(e => e.id === entrance.value);
  const entry = selectedTeacher();
  onShow3D({route, targetId: selectedId, startId: origin.startRoomId, entrance: origin,
   teacherNames: teacher ? [teacher] : [], demo: mode === 'teacher' && demo,
   eventRoom: entry?.room || '', eventLocation: entry?.room ? eventLocation(entry) : ''});
 }
 button.onclick = showSelected;
 const pending = document.getElementById('live-tour-pending'), link = document.getElementById('live-tour-link');
 try {
  const url = new URL(config.liveTourUrl);
  if (url.protocol === 'https:') { link.href = url.href; link.hidden = false; pending.hidden = true; }
 } catch {}
 fill();
 return {selectRoom, showSelected, setReady(value, error = false) {ready = value; loadError = error; update();}, getSelectedId: () => selectedId};
}
