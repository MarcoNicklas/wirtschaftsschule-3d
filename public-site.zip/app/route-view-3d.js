import * as THREE from 'three';

// Straight segments retain the tested 2D path; smoothing could cut a door corner.
export function routePoints3D(points,level){
 const result=[];
 for(const p of points){const q=[p[0],level+.12,-p[1]];if(!result.length||Math.hypot(...q.map((v,i)=>v-result.at(-1)[i]))>.001)result.push(q)}
 return result;
}
export function createRouteView3D(scene){
 let group=null,markers=[];
 const ray=new THREE.Raycaster(),viewport=new THREE.Vector2(),worldPosition=new THREE.Vector3();
 function clear(){markers=[];if(!group)return;const materials=new Set();group.traverse(o=>{o.geometry?.dispose();if(o.material)materials.add(o.material)});materials.forEach(m=>{m.map?.dispose();m.dispose()});scene.remove(group);group=null}
 function pin(text,position,{stageIndex,label='',current=false}={}){
  const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
  ctx.font='600 26px system-ui';canvas.width=label?Math.min(420,110+Math.ceil(ctx.measureText(label).width)):88;canvas.height=104;
  ctx.fillStyle=current?'#1769eb':'#ffffff';ctx.strokeStyle='#1769eb';ctx.lineWidth=4;
  ctx.beginPath();ctx.roundRect(4,4,canvas.width-8,80,40);ctx.fill();ctx.stroke();
  ctx.beginPath();ctx.moveTo(canvas.width/2-10,83);ctx.lineTo(canvas.width/2,100);ctx.lineTo(canvas.width/2+10,83);ctx.fill();
  ctx.fillStyle=current?'#ffffff':'#1769eb';ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='700 38px system-ui';ctx.fillText(String(text),label?44:canvas.width/2,45);
  if(label){ctx.font='600 26px system-ui';ctx.textAlign='left';ctx.fillStyle='#183e69';ctx.fillText(label,82,45,canvas.width-94)}
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
  const marker=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,transparent:true,depthTest:false,depthWrite:false,toneMapped:false}));
  marker.position.copy(position).add(new THREE.Vector3(0,.5,0));marker.center.set(.5,0);marker.renderOrder=110;
  marker.name=label?'Ziel_'+label:'Wegschritt_'+text;marker.userData.routeStage=stageIndex;
  marker.onBeforeRender=(renderer,scene,camera)=>{renderer.getSize(viewport);marker.getWorldPosition(worldPosition);const height=2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*camera.position.distanceTo(worldPosition)*40/Math.max(1,viewport.y);marker.scale.set(height*canvas.width/canvas.height,height,1)};
  group.add(marker);markers.push(marker);
 }
 function show({points,level,points3D,stageIndex=0,stageCount=1,targetLabel='Ziel'}){
  clear();const vertices=(points3D??routePoints3D(points,level)).map(p=>new THREE.Vector3(...p));if(vertices.length<2)return null;
  group=new THREE.Group();group.name='Blaue_Wegfuehrung';
  const blue=new THREE.MeshBasicMaterial({color:0x1769eb,transparent:true,depthTest:false,depthWrite:false}),white=new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,depthTest:false,depthWrite:false});
  function mesh(geometry,material,position){const o=new THREE.Mesh(geometry,material);o.position.copy(position);o.renderOrder=100;group.add(o);return o}
  function line(a,b,radius){const d=b.clone().sub(a),o=mesh(new THREE.CylinderGeometry(radius,radius,d.length(),12),blue,a.clone().add(b).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize())}
  vertices.forEach(p=>mesh(new THREE.SphereGeometry(.13,12,8),blue,p));
  for(let i=1;i<vertices.length;i++){
   const a=vertices[i-1],b=vertices[i],d=b.clone().sub(a);line(a,b,.13);
   if(d.length()>1.8){const arrow=mesh(new THREE.ConeGeometry(.24,.7,14),blue,a.clone().lerp(b,.62).add(new THREE.Vector3(0,.07,0)));arrow.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize())}
  }
  const start=vertices[0],end=vertices.at(-1);
  for(const p of[start,end]){const disk=mesh(new THREE.CylinderGeometry(.3,.3,.035,32),white,p);const ring=mesh(new THREE.TorusGeometry(.3,.06,10,32),blue,p.clone().add(new THREE.Vector3(0,.025,0)));ring.rotation.x=Math.PI/2}
  if(start.distanceTo(end)>1)pin(stageIndex+1,start,{stageIndex,current:true});
  if(stageIndex<stageCount-1)pin(stageIndex+2,end,{stageIndex:stageIndex+1});
  else pin('✓',end,{stageIndex,label:targetLabel});
  scene.add(group);return group;
 }
 function pick(ndc,camera){if(!group?.visible)return null;ray.setFromCamera(ndc,camera);return ray.intersectObjects(markers,false)[0]?.object.userData.routeStage??null}
 return{show,clear,pick,setOffset:y=>{if(group)group.position.y=y},setVisible:visible=>{if(group)group.visible=visible}};
}
