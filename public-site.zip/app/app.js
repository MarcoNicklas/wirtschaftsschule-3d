const MODEL_REVISION='4eca80651b0a';
import {buildRouteStages,routeMeshInStage,routeStageLabels} from './route-stages.js?v=8972cb119200';
import {createRouteView3D} from './route-view-3d.js?v=20a10dbe8365';
import {routeCameraFrame} from './route-camera.js?v=197a9707f47b';
import {initRoomAssignments} from './room-assignments.js?v=854d6a514e61';
import {initVisitorNavigation} from './visitor-navigation.js?v=4ae1283ad2f8';
import * as THREE from 'three';
import {createFloorContext} from './floor-context.js?v=e4ee31c92e3b';
import {GLTFLoader} from './vendor/loaders/GLTFLoader.js';
import {DRACOLoader} from './vendor/loaders/DRACOLoader.js';
import {OrbitControls} from './vendor/controls/OrbitControls.js';
const $=id=>document.getElementById(id),host=$('canvas'),scene=new THREE.Scene();
scene.background=null;
const camera=new THREE.PerspectiveCamera(42,1,.01,5000),renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});
renderer.localClippingEnabled=true;
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.85;renderer.outputColorSpace=THREE.SRGBColorSpace;host.append(renderer.domElement);
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');let cameraFlight=null,hasFramed=false,renderedPose=null;
const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.08;controls.maxPolarAngle=Math.PI*.95;controls.autoRotateSpeed=.8;
scene.add(new THREE.HemisphereLight(0xffffff,0x718268,1.6));const sun=new THREE.DirectionalLight(0xffffff,2);sun.position.set(30,60,30);scene.add(sun);
const loader=new GLTFLoader(),draco=new DRACOLoader();draco.setDecoderPath('./vendor/draco/');loader.setDRACOLoader(draco);
const [data,combined]=await Promise.all([fetch('./assets/Raumfassung_Analyse.json?v=6d3281d4e1e9').then(r=>r.json()),fetch('./assets/Gesamtmodell_Quellenabgleich.json?v=98cd9728c498').then(r=>r.json())]);
const [entranceRoutes,visitorConfig]=await Promise.all([fetch('./assets/entrance-routes.json?v=e183cf6e87f1').then(r=>{if(!r.ok)throw new Error('routes');return r.json()}).catch(()=>({entrances:[],routes:{},unavailableData:true})),fetch('./assets/visitor-config.json?v=60f0a4cee0aa').then(r=>{if(!r.ok)throw new Error('config');return r.json()}).catch(()=>({}))]);
combined.rooms=combined.rooms.filter(r=>r.storey!=='UG').map(r=>({...r,floor:r.zone,display_name:r.id==='Windfang_E_50b'?'Eingang Aula':r.display_name,source_name:r.id==='Windfang_E_50b'?'Eingang Aula':r.display_name||r.name,plan_source_name:r.name,area_from_polygon_m2:r.area_m2,level_m:r.level_m??r.z_m}));
let model=null,contextModel=null,box=new THREE.Box3(),size=new THREE.Vector3(),center=new THREE.Vector3(),extent=10,loadId=0,labels=[],roomData=combined.rooms,selection=null;
let visitorNav=null,assignments=null,activeRoute=null,routeRequest=0,viewBeforeRoute=null,exploded=false;
const floorContext=createFloorContext(scene,combined.rooms);
const routeView=createRouteView3D(scene);
const roomLabel=r=>whole()?(assignments?.displayName(r)??r.source_name):r.source_name;
function shortRoomLabel(r){let n=assignments?.getAssignment(r.id)?.room_name||r.short_label||r.display_name||r.source_name;const compact={'Toiletten Männer':'WC Männer','Toiletten Frauen':'WC Frauen','Toiletten Lehrkräfte':'WC Lehrkräfte','Büro Hausmeister':'Hausmeister','Lehrerzimmer · Teilbereich':'Lehrerzimmer · Teil'};n=compact[n]||n.replace(/\s*·\s*(Nummer.*|Nutzung.*|Zuordnung.*|Plan.*)$/i,'');n=n.replace(/^Eingang West$/,'Eingang Aula').replace(/^Eingang Ost$/,'Eingang Parkplatz');return n.length>28?n.slice(0,26)+'…':n}
function showRoomDetail(r){
 const card=$('room-detail');card.hidden=!r||!whole();if(card.hidden)return;
 const saved=assignments?.getAssignment(r.id),f=combined.room_furniture?.rooms?.find(x=>x.room_id===r.id);
 $('room-detail-name').textContent=saved?.room_name||r.display_name||r.source_name;
 const usage=saved?.usage||r.usage;
 $('room-detail-meta').textContent=[storeys[r.storey],usage&&usage!==r.display_name?usage:null].filter(Boolean).join(' · ');
 $('room-detail-people').textContent=(r.occupants??[]).join(' · ');$('room-detail-people').hidden=!(r.occupants??[]).length;
 let equipment=f?(f.computers?f.computers+' PC-Arbeitsplätze':f.chairs+' Schülerplätze')+' · '+f.tables+' Zweiertische · 1 Tafel'+(f.teacher_desks?'. Lehrerpult links zur Tafel: höhenverstellbar, mit PC, Tastatur und Dokumentenkamera.':''):'';
 if(r.id==='Pausenhalle_E_50'&&combined.aula_terraces)equipment='Drei Podestebenen mit Zwischenstufen. Drei Tischgruppen mit zwölf Stühlen auf dem obersten Podest, Kicker neben dem Pausenverkauf.';
 if(r.id==='E_85a'&&combined.makerspace_equipment)equipment='Robotik: humanoider Roboter und kleine Industrieroboter. Zwei 3D-Drucker sowie Spiele und Material für Gamification.';
 $('room-detail-furniture').hidden=!equipment;$('room-detail-furniture').textContent=equipment;
 const note=[saved?.location_note,saved?.door_note,f?'Bestuhlung als Entwurf · Maße und Abstände angenähert.':r.id==='E_85a'&&combined.makerspace_equipment?'Geräte und Aufstellung schematisch dargestellt.':(!usage&&!r.user_confirmed?'Nutzung noch offen.':null)].filter(Boolean).join(' ');
 $('room-detail-note').textContent=note;$('room-detail-note').hidden=!note
}
const cache=new Map(),meshIndex=combined.mesh_index??{},levels=[...new Set(Object.values(meshIndex).map(m=>m.level_m).concat(combined.rooms.map(r=>r.level_m)))].filter(Number.isFinite).sort((a,b)=>a-b);
const storeys={EG:'Erdgeschoss','1OG':'1. Obergeschoss','2OG':'2. Obergeschoss'};
const zones={UG_EG:'Plan UG / EG',EG_1OG:'Plan EG / 1. OG','1OG_2OG':'Plan 1. OG / 2. OG','2OG':'Plan oberstes 2. OG'};
const planFiles={UG_EG:'Plan_UG_EG.jpg',EG_1OG:'Plan_EG_1OG.jpg','1OG_2OG':'Plan_1OG_2OG.jpg','2OG':'Plan_2OG.jpg'};
const metadata={gesamtmodell:['Gesamtmodell · alle Stockwerke',`${combined.rooms.length} Räume und Bereiche · 3D-Orientierung`],raumfassung:['Separate Polycam-Raumfassung','Originale Exportbereiche · Lagezuordnung offen'],'scan-30':['Texturierter Scan · 30.10.2026','Originalgeometrie · Scanlücken und Drift bleiben sichtbar'],'scan-27':['Texturierter Scan · 27.10.2026','Originalgeometrie · Scanlücken bleiben sichtbar'],'vergleich-alt':['Bisheriges Druckmodell','Frühere schematische Fassung zum Vergleich']};
const whole=()=>$('model').value==='gesamtmodell',structured=()=>['raumfassung','gesamtmodell'].includes($('model').value);
const roomPrefix=r=>r.zone?r.zone+'__'+r.id:r.id;
function meshMeta(o){return meshIndex[o.name]??o.userData?.metadata??o.userData??{}}
function inferred(m){return m.inferred===true||m.evidence==='inferred'||m.evidence==='logical'||/ergänz|ergaenz|inferred|assumption|logisch/i.test(String(m.evidence??''))}
function isRoof(o){return meshMeta(o).kind==='roof'||o.name.includes('Dach')}
function isGlass(o){const m=meshMeta(o);return m.kind==='window'&&(m.window_detail==='glazing'||m.glazing===true||/Fensterband|F2_Windows/i.test(o.name))}
function selectedStorey(){return whole()&&$('floor').value.startsWith('storey:')?$('floor').value.slice(7):null}
function visibleStoreys(m){return (m.visible_storeys??[m.storey]).filter(s=>Object.hasOwn(storeys,s))}
function displayLevel(m){const focused=selectedStorey();return focused?(m.display_levels_m?.[focused]??m.level_m):(m.primary_display_level_m??m.level_m)}
function offset(level){if(!whole()||activeRoute)return 0;const order=Object.keys(storeys),storey=combined.rooms.find(r=>r.level_m===level)?.storey,rank=order.indexOf(storey),focused=selectedStorey();if(rank<0)return 0;return exploded?rank*14:focused?(rank-order.indexOf(focused))*7:0}
function updateViewMode(){const focused=selectedStorey();document.querySelectorAll('[data-floor]').forEach(b=>{b.disabled=!model||!whole();b.setAttribute('aria-pressed',!exploded&&(!activeRoute||currentStage()?.kind==='walk')&&b.dataset.floor===$('floor').value)});$('floor-view').setAttribute('aria-pressed',!exploded);$('exploded').setAttribute('aria-pressed',exploded);$('roofs').disabled=Boolean(focused)||exploded;if($('roofs').disabled)$('roofs').checked=false;if(whole())$('view-label').textContent=activeRoute?(currentStage().viewCaption||currentStage().title):(exploded?'Explosionsansicht':'Stockwerksansicht')+' · '+$('floor').selectedOptions[0].textContent;floorContext.update({enabled:whole()&&Boolean(focused)&&!activeRoute,focusedStorey:focused,offset,exploded});if(contextModel)contextModel.visible=whole()&&$('context').checked&&!focused&&!exploded&&!activeRoute}
function floorHeadings(){if(!whole()||!$('room-labels').checked||activeRoute)return;const focused=selectedStorey();if(!focused&&!exploded)return;for(const a of floorContext.labelAnchors(offset)){sprite(storeys[a.storey]+(a.storey===focused?' · im Fokus':''),a.position,4,6,a.storey!==focused&&Boolean(focused))}}

function roomPosition(r){const p=[...r.center];p[1]+=offset(r.level_m);return p}
let resizeTimer;
function resize(){const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(model){if(activeRoute)frameRoute();else if(selection)frameRoom(selection);else frame()}},140)}new ResizeObserver(resize).observe(host);
function clearLabels(){labels.forEach(s=>{scene.remove(s);s.material.map.dispose();s.material.dispose()});labels=[]}
function sprite(text,pos,scale=6,priority=0,muted=false){const c=document.createElement('canvas'),ctx=c.getContext('2d');ctx.font='600 32px system-ui';c.width=Math.min(720,Math.ceil(ctx.measureText(text).width)+28);c.height=58;ctx.fillStyle=muted?'#edf0e7b0':'#fcfcf4ed';ctx.beginPath();ctx.roundRect(0,0,c.width,58,10);ctx.fill();ctx.font='600 32px system-ui';ctx.textAlign='center';ctx.fillStyle=muted?'#71827a':'#254431';ctx.fillText(text,c.width/2,40,c.width-20);const texture=new THREE.CanvasTexture(c);texture.colorSpace=THREE.SRGBColorSpace;const s=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,depthTest:false,toneMapped:false}));s.position.set(...pos);s.position.y+=.3;s.userData.label={priority,pixels:scale<5?15:23,aspect:c.width/c.height};const position=new THREE.Vector3();s.onBeforeRender=()=>{s.getWorldPosition(position);const pixels=scale<5?15:23,height=2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*camera.position.distanceTo(position)*pixels/Math.max(1,host.clientHeight);s.scale.set(height*c.width/c.height,height,1)};scene.add(s);labels.push(s)}
function layoutLabels(){camera.updateMatrixWorld();const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;const occupied=[];const ordered=[...labels].sort((a,b)=>(b.userData.label?.priority??0)-(a.userData.label?.priority??0)||camera.position.distanceToSquared(a.position)-camera.position.distanceToSquared(b.position));for(const s of ordered){s.visible=false;const p=s.position.clone().project(camera),view=s.position.clone().applyMatrix4(camera.matrixWorldInverse),d=-view.z;if(d<=0||p.z < -1||p.z>1)continue;const info=s.userData.label,ph=info.pixels*camera.position.distanceTo(s.position)/d,pw=ph*info.aspect,x=(p.x+1)*w/2,y=(1-p.y)*h/2;const rect={l:x-pw/2-4,r:x+pw/2+4,t:y-ph/2-3,b:y+ph/2+3};if(rect.r<0||rect.l>w||rect.b<0||rect.t>h)continue;if(occupied.some(a=>rect.l<a.r&&rect.r>a.l&&rect.t<a.b&&rect.b>a.t))continue;s.visible=true;occupied.push(rect)}}
function inFilter(r){const f=$('floor').value;if(f==='all')return true;if(!whole())return String(r.floor)===f;return f.startsWith('storey:')?r.storey===f.slice(7):r.zone===f.slice(5)}
function filteredRooms(){const q=$('room-search').value.toLowerCase().trim();return roomData.filter(r=>inFilter(r)&&(!q||`${roomLabel(r)} ${r.source_name} ${(r.occupants??[]).join(" ")} ${r.short_label??""} ${r.display_name?"":r.id}`.toLowerCase().includes(q)))}
function configure(){const on=whole();roomData=on?combined.rooms:data.rooms;$('floor').replaceChildren();
 if(on){$('floor').append(new Option('Gesamtes Gebäude','all'));for(const [s,n]of Object.entries(storeys))$('floor').append(new Option(n,'storey:'+s));}
 else for(const[v,n]of Object.entries({'2':'Floor 2 · kompakter Raumtrakt','1':'Floor 1 · unvollständige Konturen',all:'Beide Exportbereiche'}))$('floor').append(new Option(n,v));
 $('floor').value=on?'storey:EG':'2';$('room-search').value='';exploded=false;updateViewMode();
}
function updateSources(){if(!$('plan-links'))return;const f=$('floor').value;let zs=f.startsWith('zone:')?[f.slice(5)]:[...new Set(roomData.filter(inFilter).map(r=>r.zone))];$('plan-links').replaceChildren();zs.filter(z=>planFiles[z]).forEach(z=>{const a=document.createElement('a');a.href='./assets/'+planFiles[z];a.textContent=zones[z]+' ↗';a.target='_blank';a.rel='noopener';$('plan-links').append(a)})}
function entranceLabels(){
 if(!whole()||!$('room-labels').checked||$('floor').value==='all')return;
 const f=$('floor').value;if(!(f==='storey:EG'||f==='zone:UG_EG'))return;
 for(const e of combined.user_entrances??[]){if(!e.external||!Array.isArray(e.center_xy_m)||/west/i.test(e.label))continue;const label=/ost/i.test(e.label)?'Eingang Parkplatz':e.label;sprite(label,[e.center_xy_m[0],-1.25+offset(-1.55),-e.center_xy_m[1]],3.5)}
}
function updateRooms(){
 const on=structured();$('floor-control').hidden=!on;$('building-controls').hidden=!whole();clearLabels();if(!on)return;
 const rs=filteredRooms();if(whole()&&!activeRoute){if($('floor').value!=='all'&&$('room-labels').checked)rs.forEach(r=>sprite(shortRoomLabel(r),roomPosition(r),3.5,r.user_confirmed?2:0));entranceLabels();floorHeadings()}
}
function setFloor(reframe=true){if(!model||!structured())return;const f=$('floor').value;updateViewMode();
 model.traverse(o=>{if(!o.isMesh)return;const m=meshMeta(o);let visible=f==='all';if(whole()){const assigned=visibleStoreys(m);visible=visible||(f.startsWith('storey:')?assigned.includes(f.slice(7)):m.zone===f.slice(5));if(isRoof(o)&&!$('roofs').checked)visible=false;if(m.kind==='support')visible=false;if(activeRoute)visible=routeMeshVisible(o,m);if(!assigned.length)visible=false;if(inferred(m)&&!isRoof(o)&&!$('additions').checked)visible=false;o.position.copy(o.userData.basePosition);o.position.y+=offset(displayLevel(m))}else visible=visible||o.name.startsWith('F'+f+'_');o.visible=visible;
 const mats=Array.isArray(o.material)?o.material:[o.material];mats.forEach(mat=>{if(mat.emissive)mat.emissive.set(whole()&&$('highlight').checked&&inferred(m)?'#77500f':'#000000');if(mat.userData.baseColor)mat.color.copy(whole()&&$('highlight').checked&&inferred(m)?new THREE.Color('#c99643'):mat.userData.baseColor)})});
 updateRooms();selection=null;showRoomDetail(null);$('room-route').disabled=true;refreshRoute();$('selection').textContent='Kein Raum ausgewählt';if(reframe){if(activeRoute)frameRoute();else frame()};
}
function calculateBounds(){box.makeEmpty();model?.traverse(o=>{if(o.isMesh&&o.visible)box.expandByObject(o)});if(box.isEmpty())box.setFromCenterAndSize(new THREE.Vector3(),new THREE.Vector3(10,10,10));box.getSize(size);box.getCenter(center);extent=Math.max(size.x,size.y,size.z,1e-3)}
function moveTo(target,delta){
 
 const destination=target.clone().add(delta);camera.near=Math.max(extent/10000,.0001);camera.far=Math.max(extent*100,100);camera.updateProjectionMatrix();controls.minDistance=extent*.015;controls.maxDistance=extent*8;
 if(hasFramed&&!reducedMotion.matches&&renderedPose){
  camera.position.copy(renderedPose.position);controls.target.copy(renderedPose.target);
  cameraFlight={start:performance.now(),position:renderedPose.position.clone(),target:renderedPose.target.clone(),endPosition:destination,endTarget:target.clone()};controls.enabled=false
 }else{cameraFlight=null;controls.enabled=true;controls.target.copy(target);camera.position.copy(destination);controls.update()}
 hasFramed=true
}
function tickCamera(now){
 if(!cameraFlight)return;const f=cameraFlight,t=Math.min(1,(now-f.start)/700),e=t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
 camera.position.lerpVectors(f.position,f.endPosition,e);controls.target.lerpVectors(f.target,f.endTarget,e);
 if(t===1){cameraFlight=null;controls.enabled=true}
}
renderer.domElement.addEventListener('pointerdown',()=>{cameraFlight=null;controls.enabled=true});
reducedMotion.addEventListener('change',()=>{if(reducedMotion.matches&&cameraFlight){camera.position.copy(cameraFlight.endPosition);controls.target.copy(cameraFlight.endTarget);cameraFlight=null;controls.enabled=true}});
function frame(mode='iso'){
 
 calculateBounds();const direction=(mode==='top'?new THREE.Vector3(0,1,.0001):(whole()&&$('floor').value!=='all'?(camera.aspect<1?new THREE.Vector3(1.2,1.3,.65):new THREE.Vector3(.1,1.15,1)):new THREE.Vector3(1,.9,1))).normalize();camera.position.copy(center).add(direction);camera.lookAt(center);
 const inverse=camera.quaternion.clone().invert(),tan=Math.tan(THREE.MathUtils.degToRad(camera.fov/2)),points=[],projected=new THREE.Box3();model.updateMatrixWorld(true);
 model.traverse(o=>{if(!o.isMesh||!o.visible)return;if(!o.geometry.boundingBox)o.geometry.computeBoundingBox();const b=o.geometry.boundingBox;for(const x of[b.min.x,b.max.x])for(const y of[b.min.y,b.max.y])for(const z of[b.min.z,b.max.z]){const p=new THREE.Vector3(x,y,z).applyMatrix4(o.matrixWorld).sub(center).applyQuaternion(inverse);points.push(p);projected.expandByPoint(p)}});
 const middle=projected.isEmpty()?new THREE.Vector3():projected.getCenter(new THREE.Vector3());middle.z=0;let distance=1;for(const p of points)distance=Math.max(distance,p.z+Math.max(Math.abs(p.x-middle.x)/(tan*camera.aspect),Math.abs(p.y-middle.y)/tan));const target=center.clone().add(middle.applyQuaternion(camera.quaternion));moveTo(target,direction.multiplyScalar(distance*1.16))
}
function frameRoom(r){if(!whole()||!r.polygon_xy_m){const s=Math.max(Math.sqrt(r.area_from_polygon_m2),4);moveTo(new THREE.Vector3(...roomPosition(r)),new THREE.Vector3(s*.8,s*1.2,s*.9));return}const b=new THREE.Box3();for(const p of r.polygon_xy_m){b.expandByPoint(new THREE.Vector3(p[0],r.level_m+offset(r.level_m),-p[1]));b.expandByPoint(new THREE.Vector3(p[0],r.level_m+offset(r.level_m)+2.5,-p[1]))}const target=b.getCenter(new THREE.Vector3()),dir=new THREE.Vector3(.1,1.4,1).normalize();camera.position.copy(target).add(dir);camera.lookAt(target);const inv=camera.quaternion.clone().invert(),tan=Math.tan(THREE.MathUtils.degToRad(camera.fov/2));let distance=1;for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z]){const p=new THREE.Vector3(x,y,z).sub(target).applyQuaternion(inv);distance=Math.max(distance,p.z+Math.max(Math.abs(p.x)/(tan*camera.aspect),Math.abs(p.y)/tan))}moveTo(target,dir.multiplyScalar(distance*1.2))}
function focusRoom(r){if(activeRoute&&activeRoute.targetId!==r.id)clearRoute();if(whole()&&(!inFilter(r)||$('floor').value==='all'||$('roofs').checked)){$('floor').value='storey:'+r.storey;$('roofs').checked=false;setFloor(false)}selection=r;showRoomDetail(r);$('room-route').disabled=!whole();document.querySelectorAll('.room').forEach(b=>b.classList.toggle('active',b.dataset.id===r.id));clearLabels();if(whole()&&$('room-labels').checked){filteredRooms().filter(x=>x.id!==r.id).forEach(x=>sprite(shortRoomLabel(x),roomPosition(x),3.5,x.user_confirmed?2:0));entranceLabels();floorHeadings()}sprite(shortRoomLabel(r),roomPosition(r),4.5,10);frameRoom(r);if(whole()){assignments?.selectRoom(r,{reveal:false});visitorNav?.selectRoom(r.id)}$('selection').textContent=roomLabel(r);model.traverse(o=>{if(o.isMesh&&o.material.emissive)o.material.emissive.set(o.name.startsWith(roomPrefix(r)+'_')?'#3b5424':whole()&&$('highlight').checked&&inferred(meshMeta(o))?'#77500f':'#000000')})}
async function load(){showRoomDetail(null);const id=++loadId,key=$('model').value;$('status').hidden=false;$('status').textContent='Modell wird geladen …';$('view-label').textContent=metadata[key][0];$('legend-text').textContent=metadata[key][1];document.querySelector('.legend').hidden=!whole();$('download').href='./assets/'+key+'.glb';try{
 let next=cache.get(key);if(!next){const gltf=await loader.loadAsync('./assets/'+key+'.glb'+(key==='gesamtmodell'?'?v='+MODEL_REVISION:''));next=gltf.scene;next.traverse(o=>{if(!o.isMesh)return;o.userData.basePosition=o.position.clone();if(key.startsWith('scan')){const old=o.material;o.material=new THREE.MeshBasicMaterial({map:old.map,side:THREE.DoubleSide,toneMapped:false})}else{let mats=Array.isArray(o.material)?o.material:[o.material];mats=mats.map(m=>{const c=m.clone();c.side=THREE.DoubleSide;c.metalness=0;c.roughness=.85;if(o.geometry.attributes.color)c.color.set(0xffffff);return c});o.material=mats.length===1?mats[0]:mats}
 if(key==='gesamtmodell'&&o.name.includes('_Boden')){o.material=new THREE.MeshBasicMaterial({color:0xc8bfae,side:THREE.DoubleSide,toneMapped:false})}
 if(key==='gesamtmodell'&&isGlass(o)){o.material=new THREE.MeshBasicMaterial({color:0xe7f3f2,transparent:true,opacity:.045,depthWrite:false,side:THREE.FrontSide,toneMapped:false})}
 (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.userData.baseColor=m.color.clone());});next.updateMatrixWorld(true);next.traverse(o=>{if(!o.isMesh)return;if(!o.geometry.boundingBox)o.geometry.computeBoundingBox();const b=o.geometry.boundingBox.clone().applyMatrix4(o.matrixWorld);o.userData.routeBounds={min:b.min.toArray(),max:b.max.toArray()}});cache.set(key,next)}
 if(id!==loadId)return;visitorNav?.setReady(true);if(model)scene.remove(model);model=next;scene.add(model);if(contextModel)contextModel.visible=whole()&&$('context').checked;$('status').hidden=true;if(structured()){configure();setFloor()}else{floorContext.update({enabled:false,offset});model.traverse(o=>o.visible=true);updateRooms();frame()}
 }catch(e){visitorNav?.setReady(false);$('status').textContent='Das Schulmodell konnte nicht geladen werden. Bitte laden Sie die Seite erneut.';console.error(e)}}
$('model').onchange=()=>{clearRoute(false);load()};
$('floor').onchange=()=>{clearRoute(false);$('room-search').value='';$('room-labels').checked=true;$('roofs').checked=$('floor').value==='all'&&!exploded;setFloor()};
document.querySelectorAll('[data-floor]').forEach(b=>b.onclick=()=>{if(activeRoute){if(b.dataset.floor==='all'){frameRoute();return}const storey=b.dataset.floor.slice(7);let i=activeRoute.stages.findIndex(s=>s.kind==='walk'&&s.storeys.includes(storey));if(i<0)i=activeRoute.stages.findIndex(s=>s.storeys.includes(storey));if(i>=0){setRouteStage(i);return}}exploded=false;$('floor').value=b.dataset.floor;$('floor').onchange()});
$('room-search').oninput=updateRooms;
$('reset').onclick=()=>{clearRoute(false);if(whole()){exploded=false;$('room-search').value='';$('floor').value='all';$('roofs').checked=true;setFloor()}else frame()};
$('top').onclick=()=>{frame('top')};
$('floor-view').onclick=()=>{clearRoute(false);exploded=false;$('roofs').checked=$('floor').value==='all';setFloor()};
$('exploded').onclick=()=>{clearRoute(false);exploded=true;$('room-search').value='';$('floor').value='all';$('room-labels').checked=true;$('roofs').checked=false;setFloor()};
for(const id of ['roofs','additions','highlight','room-labels'])$(id).onchange=()=>setFloor(false);
$('rotate').onclick=()=>{controls.autoRotate=!controls.autoRotate;$('rotate').setAttribute('aria-pressed',controls.autoRotate)};
$('photo').onclick=()=>{renderer.render(scene,camera);const url=renderer.domElement.toDataURL('image/png');$('photo-image').src=url;$('photo-save').href=url;$('photo-dialog').showModal()};$('photo-close').onclick=()=>$('photo-dialog').close();
$('context').onchange=async()=>{if($('context').checked&&!contextModel){try{const g=await loader.loadAsync('./assets/aussenkontext.glb');contextModel=g.scene;contextModel.traverse(o=>{if(o.isMesh){o.material.metalness=0;o.material.roughness=1}});scene.add(contextModel)}catch(e){$('context').checked=false;$('status').hidden=false;$('status').textContent='Außenbereich konnte nicht geladen werden.';return}}updateViewMode()};
function pointerPosition(e){const r=renderer.domElement.getBoundingClientRect();return new THREE.Vector2((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1)}
let down;renderer.domElement.addEventListener('pointerdown',e=>down=[e.clientX,e.clientY]);
renderer.domElement.addEventListener('pointerup',e=>{
 if(!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>5||!structured())return;
 const ndc=pointerPosition(e);
 if(activeRoute){const index=routeView.pick(ndc,camera);if(index!==null)setRouteStage(index);return}
 const ray=new THREE.Raycaster();ray.setFromCamera(ndc,camera);
 const hits=ray.intersectObject(model,true).filter(h=>h.object.visible);
 const room=hits.map(h=>roomData.find(r=>meshMeta(h.object).room_id===r.id||h.object.name.startsWith(roomPrefix(r)+'_'))).find(Boolean);if(room)focusRoom(room)
});
renderer.domElement.addEventListener('pointermove',e=>{if(activeRoute&&!e.buttons)renderer.domElement.style.cursor=routeView.pick(pointerPosition(e),camera)!==null?'pointer':'grab'});


function currentStage(){return activeRoute?.stages[activeRoute.stageIndex]}
function routeMeshVisible(o,m){return routeMeshInStage(m,o.name,o.userData.routeBounds,currentStage())}
function routeTransparency(){
 const stage=currentStage(),on=Boolean(activeRoute&&whole());
 const low=stage?Math.min(...stage.levels):0,high=stage?Math.max(...stage.levels):0;
 const planes=on?[new THREE.Plane(new THREE.Vector3(0,1,0),-low+.22),new THREE.Plane(new THREE.Vector3(0,-1,0),high+(stage.kind==='stairs'?.28:2.65))]:null;
 model?.traverse(o=>{if(!o.isMesh)return;const meta=meshMeta(o),kind=meta.kind;
  for(const mat of(Array.isArray(o.material)?o.material:[o.material])){
   if(!mat.userData.routeBase)mat.userData.routeBase={opacity:mat.opacity,transparent:mat.transparent,depthWrite:mat.depthWrite};
   const base=mat.userData.routeBase,stairStage=stage?.kind==='stairs';
   const cap=stairStage?(kind==='floor'?.28:kind==='stair'?1:.25):kind==='furniture'?.35:kind==='wall'?.65:kind==='door'?.75:1;
   const fade=on&&cap<1;
   mat.opacity=on?Math.min(base.opacity,cap):base.opacity;
   if(on&&kind==='floor'&&meta.room_id===activeRoute.targetId&&activeRoute.stageIndex===activeRoute.stages.length-1)mat.color.set('#b7daf3');
   mat.transparent=fade||base.transparent;mat.depthWrite=fade?false:base.depthWrite;mat.clippingPlanes=on?planes:null;mat.needsUpdate=true;
  }
 });
}
function clearRoute(restore=true){
 renderer.domElement.style.cursor='';
 document.body.classList.remove('route-editing');$('route-edit').setAttribute('aria-expanded','false');
 routeRequest++;const previous=viewBeforeRoute;viewBeforeRoute=null;activeRoute=null;routeView.clear();$('route-steps').hidden=true;document.body.classList.remove('route-active');routeTransparency();
 if(restore&&previous&&whole()){$('roofs').checked=previous.roofs;$('floor').value=previous.floor;exploded=previous.exploded;resize();setFloor()}
}
function refreshRoute(){updateViewMode();if(!activeRoute)return;routeView.setVisible(whole());$('route-steps').hidden=!whole();routeView.setOffset(0);routeTransparency()}
function frameRoute(){
 const stage=currentStage();if(!stage)return;
 calculateBounds();
 const targetRoom=activeRoute.stageIndex===activeRoute.stages.length-1?combined.rooms.find(r=>r.id===activeRoute.targetId):null;
 const roomPoints=(targetRoom?.polygon_xy_m??[]).flatMap(p=>[[p[0],targetRoom.level_m,-p[1]],[p[0],targetRoom.level_m+2.8,-p[1]]]);
 const view=routeCameraFrame({points3D:stage.points3D,kind:stage.kind,contextBounds:{min:box.min.toArray(),max:box.max.toArray()},roomPoints,aspect:camera.aspect,fov:camera.fov});
 if(view)moveTo(new THREE.Vector3(...view.target),new THREE.Vector3(...view.delta));
}
function setRouteStage(index){
 if(!activeRoute||index<0||index>=activeRoute.stages.length)return;
 activeRoute.stageIndex=index;const stage=currentStage(),target=combined.rooms.find(r=>r.id===activeRoute.targetId);
 const hints=routeStageLabels(stage,index,activeRoute.stages.length,activeRoute.entrance.label,target?shortRoomLabel(target):'Ziel');stage.viewCaption=hints.caption;
 $('floor').value=stage.kind==='walk'?'storey:'+stage.toStorey:'all';
 setFloor(false);clearLabels();routeView.show({points3D:stage.points3D,stageIndex:index,stageCount:activeRoute.stages.length,targetLabel:target?shortRoomLabel(target):'Ziel',startLabel:hints.start,endLabel:hints.end});
 $('route-stage-title').textContent=stage.title;$('route-instruction').textContent=stage.instruction;
 $('route-progress').textContent='Schritt '+(index+1)+' von '+activeRoute.stages.length;
 document.querySelectorAll('[data-route-stage]').forEach(b=>{const selected=Number(b.dataset.routeStage)===index;b.setAttribute('aria-pressed',String(selected));if(selected)b.setAttribute('aria-current','step');else b.removeAttribute('aria-current')});
 $('route-prev').disabled=index===0;$('route-next').disabled=index===activeRoute.stages.length-1;$('route-next').textContent=index===activeRoute.stages.length-1?'Ziel erreicht ✓':hints.next;
 refreshRoute();frameRoute();
}
async function show3DRoute(payload){
 clearRoute();const target=combined.rooms.find(r=>r.id===payload.targetId);if(!target||!model)return;
 const stages=buildRouteStages(payload.route,{rooms:combined.rooms,target:{...target,display_name:roomLabel(target)},entrance:payload.entrance});if(!stages.length)return;
 viewBeforeRoute={roofs:$('roofs').checked,floor:$('floor').value,exploded};activeRoute={...payload,stages,stageIndex:0};exploded=false;$('roofs').checked=false;controls.autoRotate=false;$('rotate').setAttribute('aria-pressed','false');document.body.classList.add('route-active');
 $('route-destination').textContent=(payload.teacherNames?.length?(payload.demo?'Probe · ':'')+payload.teacherNames.join(', ')+' → ':'')+roomLabel(target);
 $('route-stage-list').replaceChildren(...stages.map((stage,i)=>{const b=document.createElement('button');b.type='button';b.dataset.routeStage=i;b.setAttribute('aria-label',stage.title);b.innerHTML='<span class="route-step-number"></span><span></span>';b.firstElementChild.textContent=i+1;b.lastElementChild.textContent=stage.kind==='stairs'?'Treppe · '+({'EG':'EG','1OG':'1. OG','2OG':'2. OG'}[stage.toStorey]||'weiter'):i===0&&stages.length>1?payload.entrance.label:roomLabel(target);b.onclick=()=>setRouteStage(i);return b}));
 setRouteStage(0);resize();
}
$('route-prev').onclick=()=>setRouteStage(activeRoute.stageIndex-1);$('route-next').onclick=()=>setRouteStage(activeRoute.stageIndex+1);
$('route-focus').onclick=frameRoute;$('route-close').onclick=()=>clearRoute();
$('route-edit').onclick=()=>{const expanded=document.body.classList.toggle('route-editing');$('route-edit').setAttribute('aria-expanded',String(expanded));};
$('room-route').onclick=()=>{if(!selection)return;visitorNav?.selectRoom(selection.id);visitorNav?.showSelected()};

async function focusPermanentRoom(value){const id=typeof value==='string'?value:value.id;const r=combined.rooms.find(r=>r.id===id);if(!r)return;if(!whole()){$('model').value='gesamtmodell';await load()}if(!inFilter(r)){$('floor').value='storey:'+r.storey;setFloor()}if(model)focusRoom(r);if(matchMedia('(max-width:700px)').matches)document.querySelector('main').scrollIntoView({behavior:reducedMotion.matches?'instant':'smooth',block:'start'})}
assignments=initRoomAssignments({rooms:combined.rooms,container:document.createElement('div'),onChange:()=>{const selected=selection;updateRooms();if(selected&&whole())focusRoom(selected)},onFocus:focusPermanentRoom});
visitorNav=initVisitorNavigation({rooms:combined.rooms,routes:entranceRoutes,config:visitorConfig,container:$('visitor-navigation'),onFocusRoom:focusPermanentRoom,onShow3D:show3DRoute,onClearRoute:()=>clearRoute()});
document.querySelectorAll('.options-popover button').forEach(b=>b.addEventListener('click',()=>{document.querySelector('.view-options').open=false}));
renderer.setAnimationLoop(now=>{tickCamera(now);controls.update();renderedPose={position:camera.position.clone(),target:controls.target.clone()};layoutLabels();renderer.render(scene,camera)});resize();load();

