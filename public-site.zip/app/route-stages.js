const FLOOR_NAMES={EG:'Erdgeschoss','1OG':'1. Obergeschoss','2OG':'2. Obergeschoss'};
const EPS=.02;
const near=(a,b)=>Math.abs(a-b)<EPS;
const roomLevel=r=>Number(r?.level_m??r?.z_m);
const unique=values=>values.filter((v,i)=>values.findIndex(x=>typeof v==='number'?near(v,x):v===x)===i);
const length=points=>points.slice(1).reduce((sum,p,i)=>sum+Math.hypot(...p.map((v,k)=>v-points[i][k])),0);

// Named storeys contain two physical levels. Shared walls may span both;
// shared slabs must stay on their real level to avoid covering the route.
export function routeMeshInStage(meta,name,bounds,stage){
 if(!stage||['roof','support'].includes(meta.kind))return false;
 const low=Math.min(...stage.levels),high=Math.max(...stage.levels);
 if(stage.kind==='walk'){
  const levels=meta.kind==='floor'?[meta.level_m]:[meta.level_m,...Object.values(meta.display_levels_m??{})];
  return meta.kind!=='stair'&&levels.some(z=>Number.isFinite(z)&&near(z,stage.fromLevel));
 }
 const identity=[name,meta.room_id,meta.source_wall_node].filter(Boolean).join(' ');
 if(meta.kind!=='stair'&&!/Treppenhaus|StairBase/i.test(identity))return false;
 if(!bounds)return false;
 // Return flights retain the lower construction level in their metadata.
 // Actual world bounds, not that level, select the visible flight and landing.
 if(bounds.max[1]<low-.22||bounds.min[1]>high+.28)return false;
 const points=stage.points3D;
 return [0,2].every(axis=>bounds.max[axis]>=Math.min(...points.map(p=>p[axis]))-2.5&&bounds.min[axis]<=Math.max(...points.map(p=>p[axis]))+2.5);
}

export function routeStageLabels(stage,index,count,entranceLabel='Eingang',targetLabel='Ziel'){
 const short={EG:'EG','1OG':'1. OG','2OG':'2. OG'},from=short[stage.fromStorey]||'Start',to=short[stage.toStorey]||'Ziel';
 const last=index===count-1;
 const split=stage.kind==='stairs'&&from===to;
 return {start:index===0?entranceLabel:stage.kind==='stairs'?(split?'Treppenbeginn':from):'Ausstieg '+from,
  end:last?targetLabel:stage.kind==='stairs'?(split?'Nächste Ebene':to):'Zur Treppe',
  caption:stage.kind==='stairs'?(split?'Treppenhaus · Ebenenwechsel im '+from:'Treppenhaus · '+from+' → '+to):(FLOOR_NAMES[stage.toStorey]||'Ebene')+' · nur diese Ebene',
  next:stage.kind==='stairs'?'Am Ausstieg: weiter →':'An der Treppe: weiter →'};
}

export function storeyForLevel(level,rooms=[]){
 const counts=new Map();
 for(const room of rooms)if(FLOOR_NAMES[room.storey]&&near(roomLevel(room),level))counts.set(room.storey,(counts.get(room.storey)||0)+1);
 return [...counts].sort((a,b)=>b[1]-a[1])[0]?.[0]??null;
}

// Stages are slices of the tested route. They never smooth a corner or invent
// a shortcut. A short landing joins flights only when the direction continues.
export function buildRouteStages(route,{rooms=[],target=null,entrance=null}={}){
 const points=route?.points3D;
 if(!Array.isArray(points)||points.length<2||points.some(p=>!Array.isArray(p)||p.length!==3||!p.every(Number.isFinite)))return [];
 const raw=route.segments??[];
 let cursor=0;
 const valid=raw.length&&raw.every(s=>{
  const ok=['walk','stairs'].includes(s.type)&&Number.isInteger(s.fromIndex)&&Number.isInteger(s.toIndex)&&s.fromIndex===cursor&&s.toIndex>s.fromIndex&&s.toIndex<points.length&&Number.isFinite(s.fromLevel)&&Number.isFinite(s.toLevel);
  cursor=s.toIndex;return ok;
 })&&cursor===points.length-1;
 // Older route files can lack segment metadata; keep all original edges.
 const source=valid?raw:points.slice(1).map((p,i)=>({type:near(p[1],points[i][1])?'walk':'stairs',fromIndex:i,toIndex:i+1,fromLevel:points[i][1]-.12,toLevel:p[1]-.12}));
 const segments=[];
 for(const s of source){
  const last=segments.at(-1);
  if(last?.type==='walk'&&s.type==='walk'&&near(last.toLevel,s.fromLevel)&&near(s.fromLevel,s.toLevel)){
   last.toIndex=s.toIndex;last.toLevel=s.toLevel;
  }else segments.push({...s});
 }
 const groups=[];
 for(let i=0;i<segments.length;i++){
  const first=segments[i],parts=[first];
  if(first.type==='stairs'){
   const direction=Math.sign(first.toLevel-first.fromLevel);
   while(i+1<segments.length){
    const next=segments[i+1],landing=next.type==='walk'?next:null,flight=landing?segments[i+2]:next;
    if(!flight||flight.type!=='stairs'||Math.sign(flight.toLevel-flight.fromLevel)!==direction)break;
    if(landing&&(!near(landing.fromLevel,landing.toLevel)||length(points.slice(landing.fromIndex,landing.toIndex+1))>3))break;
    if(landing){parts.push(landing);i++}
    parts.push(flight);i++;
   }
  }
  groups.push({kind:first.type,fromIndex:first.fromIndex,toIndex:parts.at(-1).toIndex,fromLevel:first.fromLevel,toLevel:parts.at(-1).toLevel,levels:unique(parts.flatMap(s=>[s.fromLevel,s.toLevel]))});
 }
 const targetName=target?.display_name||target?.source_name||target?.name||'Ziel';
 const numbered=/^(?:E\s*)?\d+[a-z]?$/i.test(targetName);
 const destination=numbered?'Raum '+targetName:targetName;
 const resolve=level=>target&&near(roomLevel(target),level)&&FLOOR_NAMES[target.storey]?target.storey:storeyForLevel(level,rooms);
 return groups.map((group,index)=>{
  const last=index===groups.length-1,first=index===0,fromStorey=resolve(group.fromLevel),toStorey=resolve(group.toLevel);
  const storeys=unique(group.levels.map(resolve).filter(Boolean));
  let title,instruction;
  if(group.kind==='stairs'){
   const floor=FLOOR_NAMES[toStorey],up=group.toLevel>group.fromLevel;
   title=floor?'Treppe '+(toStorey==='EG'?'ins ':'zum ')+floor:'Über die Treppe';
   instruction=floor?(fromStorey===toStorey?'Im Treppenhaus zur nächsten Ebene im '+floor+' '+(up?'hinauf':'hinunter')+'gehen.':'Im Treppenhaus bis ins '+floor+' '+(up?'hinauf':'hinunter')+'gehen.'):'Den Pfeilen auf der blauen Linie über die Treppe folgen.';
  }else if(last){
   title=numbered?'Zum Raum '+targetName:'Zum Ziel';
   instruction=(first?(entrance?.label||'Am Eingang')+': ':FLOOR_NAMES[toStorey]?'Im '+FLOOR_NAMES[toStorey]+': ':'')+'Den Pfeilen auf der blauen Linie bis '+(numbered?'zum '+destination:'zum Ziel „'+destination+'“')+' folgen.';
  }else{
   title=first?'Vom Eingang zur Treppe':'Zur nächsten Treppe';
   instruction=(first?(entrance?.label||'Am Eingang')+': ':'')+'Den Pfeilen auf der blauen Linie bis zum Treppenhaus folgen.';
  }
  return {...group,points3D:points.slice(group.fromIndex,group.toIndex+1).map(p=>[...p]),storeys,fromStorey,toStorey,title,instruction};
 });
}
