import * as THREE from 'three';

// Exterior unions of the current room polygons, grouped by storey and physical
// level. Generated with Shapely: close 0.12 m gaps, simplify 0.12 m, omit holes.
// Plan [x, y] is mapped to world [x, height, -y].
const PROFILES = [{"storey":"1OG","level":1.55,"rings":[[[3.467,63.609],[-0.329,60.006],[-5.689,59.994],[-5.052,64.601],[1.403,69.881],[4.811,73.331],[21.12,73.369],[25.026,76.993],[29.385,71.87],[32.419,72.282],[29.882,75.465],[25.026,76.993],[30.472,82.046],[46.675,81.983],[53.838,72.838],[51.324,54.661],[26.561,54.754],[19.587,62.28],[10.653,62.259],[10.289,59.626],[5.525,59.615],[5.889,62.248],[3.397,63.103]]]},{"storey":"1OG","level":3.1,"rings":[[[57.186,38.426],[49.169,38.408],[44.196,44.882],[49.318,47.254],[47.289,49.967],[44.485,47.678],[42.58,50.375],[43.155,54.532],[51.248,54.623],[52.5,63.825],[60.792,63.845],[67.45,54.699],[66.463,47.559]]]},{"storey":"2OG","level":4.65,"rings":[[[26.561,54.754],[19.587,62.28],[21.12,73.369],[30.472,82.046],[46.675,81.983],[53.838,72.838],[51.324,54.661]]]},{"storey":"2OG","level":6.2,"rings":[[[42.183,47.502],[44.437,63.806],[60.792,63.845],[67.45,54.699],[66.463,47.559],[64.569,45.694],[62.738,48.028],[58.449,47.936],[61.943,43.109],[57.186,38.426],[49.169,38.408]]]},{"storey":"EG","level":-1.55,"rings":[[[19.587,62.28],[21.12,73.369],[30.472,82.046],[46.675,81.983],[53.838,72.838],[51.324,54.661],[26.561,54.754]]]},{"storey":"EG","level":0.0,"rings":[[[42.183,47.502],[43.17,54.642],[51.324,54.661],[52.57,63.825],[60.792,63.845],[67.45,54.699],[66.463,47.559],[57.186,38.426],[49.169,38.408]]]},{"storey":"UG","level":-3.1,"rings":[[[49.169,38.408],[42.183,47.502],[43.178,54.7],[51.376,54.83],[52.534,63.825],[60.792,63.845],[63.382,57.895],[65.72,53.991],[66.961,55.371],[67.45,54.699],[66.463,47.559],[57.186,38.426]]]}];
const STOREY_ORDER = ['UG', 'EG', '1OG', '2OG'];

export function createFloorContext(scene, rooms = []) {
  const group = new THREE.Group();
  group.name = 'floor-context';
  group.visible = false;
  group.raycast = () => {};
  const material = new THREE.LineBasicMaterial({
    color: 0x9aaea5,
    transparent: true,
    opacity: 0.15,
    depthTest: true,
    depthWrite: false
  });
  const available = new Set(rooms.map(room =>
    room.storey + ':' + Number(room.level_m ?? room.z_m ?? 0)));
  const profiles = PROFILES.filter(profile => !rooms.length ||
    available.has(profile.storey + ':' + profile.level)).map(profile => {
    const vertices = [];
    let leftmost = null;
    for (const ring of profile.rings) {
      for (let i = 0; i < ring.length; i++) {
        const a = ring[i], b = ring[(i + 1) % ring.length];
        vertices.push(a[0], 0, -a[1], b[0], 0, -b[1]);
        vertices.push(a[0], 2.7, -a[1], b[0], 2.7, -b[1]);
        vertices.push(a[0], 0, -a[1], a[0], 2.7, -a[1]);
        if (!leftmost || a[0] < leftmost[0]) leftmost = a;
      }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    geometry.computeBoundingSphere();
    const outline = new THREE.LineSegments(geometry, material);
    outline.name = 'floor-context-' + profile.storey + '-' + profile.level;
    outline.raycast = () => {};
    outline.position.y = profile.level;
    outline.visible = false;
    group.add(outline);
    return { ...profile, outline, leftmost };
  });
  scene.add(group);
  let lastOffset = () => 0;
  let disposed = false;

  function displacement(level, offset = lastOffset) {
    const value = typeof offset === 'function' ? Number(offset(level)) : 0;
    return Number.isFinite(value) ? value : 0;
  }

  function update({ enabled = false, focusedStorey = null, offset, exploded = false } = {}) {
    if (disposed) return;
    if (typeof offset === 'function') lastOffset = offset;
    group.visible = Boolean(enabled);
    group.userData.exploded = Boolean(exploded);
    for (const profile of profiles) {
      profile.outline.visible = Boolean(enabled) && profile.storey !== focusedStorey;
      profile.outline.position.y = profile.level + displacement(profile.level);
    }
  }

  function labelAnchors(offset = lastOffset) {
    if (disposed) return [];
    const byStorey = new Map();
    for (const profile of profiles) {
      if (!profile.leftmost) continue;
      const previous = byStorey.get(profile.storey);
      if (!previous || profile.leftmost[0] < previous.leftmost[0]) {
        byStorey.set(profile.storey, profile);
      }
    }
    return STOREY_ORDER.filter(storey => byStorey.has(storey)).map(storey => {
      const profile = byStorey.get(storey);
      return {
        storey,
        position: [
          profile.leftmost[0] - 1.4,
          profile.level + displacement(profile.level, offset) + 1,
          -profile.leftmost[1]
        ]
      };
    });
  }

  function dispose() {
    if (disposed) return;
    disposed = true;
    scene.remove(group);
    for (const profile of profiles) profile.outline.geometry.dispose();
    material.dispose();
    group.clear();
  }

  return { update, labelAnchors, dispose };
}
