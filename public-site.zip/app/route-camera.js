const dot=(a,b)=>a.reduce((sum,v,i)=>sum+v*b[i],0);
const sub=(a,b)=>a.map((v,i)=>v-b[i]);
const normal=v=>{const n=Math.hypot(...v);return v.map(x=>x/n)};
const corners=b=>[b.min[0],b.max[0]].flatMap(x=>[b.min[1],b.max[1]].flatMap(y=>[b.min[2],b.max[2]].map(z=>[x,y,z])));

// Fit the current level or isolated staircase, with room around its path.
export function routeCameraFrame({points3D,kind='walk',contextBounds,roomPoints=[],aspect=1,fov=42}){
 if(!points3D?.length)return null;
 aspect=Math.max(.25,aspect);
 const source=[...points3D,...roomPoints];
 const padding=kind==='stairs'?[2,1.1,2]:[3.4,1.8,3.4];
 const bounds={min:[0,1,2].map(i=>Math.min(...source.map(p=>p[i]))-padding[i]),max:[0,1,2].map(i=>Math.max(...source.map(p=>p[i]))+padding[i])};
 const center=bounds.min.map((v,i)=>(v+bounds.max[i])/2);
 const contextCenter=contextBounds?.min.map((v,i)=>(v+contextBounds.max[i])/2)??center;
 // Keep the camera near the current leg while retaining the school as context.
 const target=center.map((v,i)=>v*.9+contextCenter[i]*.1);
 const direction=normal(kind==='stairs'?[1,.85,1]:aspect<1?[1.2,1.7,.65]:[.12,1.7,1]);
 const right=normal([direction[2],0,-direction[0]]);
 const up=[direction[1]*right[2],direction[2]*right[0]-direction[0]*right[2],-direction[1]*right[0]];
 const tan=Math.tan(fov*Math.PI/360);
 function fit(points,margin=1){return Math.max(1,...points.map(p=>{const q=sub(p,target);return dot(q,direction)+Math.max(Math.abs(dot(q,right))/(tan*aspect),Math.abs(dot(q,up))/tan)*margin}))}
 const focusDistance=fit(corners(bounds),1.2);
 const contextDistance=contextBounds?fit(corners(contextBounds),1.08):focusDistance;
 const distance=Math.max(focusDistance,contextDistance*(aspect<1?.52:.48),13);
 return {target,direction,distance,delta:direction.map(v=>v*distance),bounds,right,up};
}
