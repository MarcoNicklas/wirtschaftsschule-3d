const VERSION="public-a199c6dad66a",base=new URL(self.registration.scope),prefix='school-unlocked-'+base.pathname;
let cleanupComplete=false;
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('message',event=>{
 if(event.data?.type==='school-public-status')event.ports[0]?.postMessage({version:VERSION,ready:cleanupComplete});
 if(event.data?.type==='school-version')event.ports[0]?.postMessage({version:VERSION});
});
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 for(const key of await caches.keys())if(key===prefix||key.startsWith(prefix))await caches.delete(key);
 await self.clients.claim();cleanupComplete=true;
 const clients=await self.clients.matchAll({type:'window'});
 for(const client of clients){const u=new URL(client.url);if(u.origin===base.origin&&u.pathname.startsWith(base.pathname))client.postMessage({type:'school-public-ready',version:VERSION});}
 await self.registration.unregister();
 for(const client of clients){const u=new URL(client.url);if(u.origin===base.origin&&u.pathname.startsWith(base.pathname+'app/')&&u.searchParams.get('public')!==VERSION){u.searchParams.set('public',VERSION);await client.navigate(u.href);}}
})()));
// Deliberately no fetch handler: public files always come from GitHub Pages.
